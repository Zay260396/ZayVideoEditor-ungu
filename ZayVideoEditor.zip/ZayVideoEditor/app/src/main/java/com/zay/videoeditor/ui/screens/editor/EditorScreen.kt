package com.zay.videoeditor.ui.screens.editor

import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.zay.videoeditor.R
import com.zay.videoeditor.data.ProjectStore
import com.zay.videoeditor.data.TimelineClip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.zay.videoeditor.data.EditorSession
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.IconCircleButton
import com.zay.videoeditor.ui.components.NeonChip
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.components.ToolTile
import com.zay.videoeditor.ui.components.ZayBackground
import com.zay.videoeditor.ui.components.showSoon
import com.zay.videoeditor.ui.theme.Navy
import com.zay.videoeditor.ui.theme.NavyCard
import com.zay.videoeditor.ui.theme.NavyCardHigh
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary
import java.util.Locale

enum class EditorPanel(val label: String, val icon: ImageVector) {
    Trim("Potong", Icons.Rounded.ContentCut),
    Music("Musik", Icons.Rounded.MusicNote),
    Teks("Teks", Icons.Rounded.TextFields),
    Effects("Efek", Icons.Rounded.AutoAwesome),
    Transition("Transisi", Icons.Rounded.SwapHoriz),
    Sticker("Stiker", Icons.Rounded.EmojiEmotions),
    Ratio("Rasio", Icons.Rounded.AspectRatio),
}

private fun formatTime(sec: Float): String {
    val m = (sec / 60f).toInt()
    val s = sec - m * 60f
    return String.format(Locale.US, "%02d:%04.1f", m, s)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(onBack: () -> Unit, onExport: () -> Unit) {
    val context = LocalContext.current
    val soon: (String) -> Unit = { stage -> showSoon(context, stage) }

    var panel by rememberSaveable { mutableStateOf<EditorPanel?>(null) }
    var selectedClip by rememberSaveable { mutableStateOf(EditorSession.clips.firstOrNull()?.id ?: -1) }
    var playhead by rememberSaveable { mutableStateOf(0f) }
    var resMenu by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val importedClips = EditorSession.clips
    val imported = importedClips.isNotEmpty()

    // Pemutar video
    val exo = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        exo.addListener(listener)
        val owner = context as? ComponentActivity
        val observer = object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                if (event == Lifecycle.Event.ON_STOP) {
                    exo.pause()
                    ProjectStore.saveCurrent(context)
                }
            }
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose {
            owner?.lifecycle?.removeObserver(observer)
            exo.removeListener(listener)
            ProjectStore.saveCurrent(context)
            exo.release()
        }
    }

    // Muat ulang daftar putar setiap kali isi timeline berubah (impor, belah, hapus, dll.)
    LaunchedEffect(importedClips.toList()) {
        if (importedClips.isEmpty()) {
            exo.clearMediaItems()
        } else {
            exo.setMediaItems(importedClips.map { it.toMediaItem() })
            exo.prepare()
            exo.seekToGlobal(importedClips, playhead)
        }
    }

    // Simpan otomatis setiap kali timeline atau resolusi berubah
    LaunchedEffect(
        importedClips.toList(),
        EditorSession.resolutionIndex,
        EditorSession.aspectIndex,
        EditorSession.fillFrame,
    ) {
        ProjectStore.saveCurrent(context)
    }

    // Playhead mengikuti pemutar saat video diputar
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            playhead = exo.globalPositionSec(importedClips)
            delay(100)
        }
        if (importedClips.isNotEmpty()) {
            playhead = exo.globalPositionSec(importedClips)
        }
    }

    val togglePlay: () -> Unit = {
        if (importedClips.isEmpty()) {
            Toast.makeText(context, "Tambahkan video dulu lewat tombol + Media", Toast.LENGTH_SHORT).show()
        } else if (exo.isPlaying) {
            exo.pause()
        } else {
            if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0, 0L)
            exo.play()
        }
    }

    // Pemilih video dari galeri
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(10),
    ) { uris ->
        if (uris.isNotEmpty()) {
            Toast.makeText(context, "Menyalin video ke proyek, tunggu sebentar...", Toast.LENGTH_SHORT).show()
            scope.launch {
                val wasEmpty = EditorSession.clips.isEmpty()
                var failed = 0
                for (uri in uris) {
                    val clip = withContext(Dispatchers.IO) { readImportedClip(context, uri) }
                    if (clip != null) EditorSession.addClip(clip) else failed++
                }
                if (wasEmpty && EditorSession.clips.isNotEmpty()) {
                    playhead = 0f
                    selectedClip = EditorSession.clips.first().id
                }
                if (failed > 0) {
                    Toast.makeText(context, "$failed video tidak bisa dibaca", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val total = if (imported) EditorSession.totalSeconds else 0f
    val clips: List<TimelineClip> = if (imported) {
        var acc = 0f
        importedClips.map { c ->
            val item = TimelineClip(c.id, 0, acc, c.durationSec, c.name)
            acc += c.durationSec
            item
        }
    } else {
        emptyList()
    }
    val videoStarts = clips.filter { it.track == 0 }.map { it.start }.sorted()
    val selected = clips.firstOrNull { it.id == selectedClip }

    // ---- Operasi edit (TAHAP 4) ----
    val toast: (String) -> Unit = { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }

    val afterEdit: () -> Unit = {
        val list = EditorSession.clips
        if (list.isEmpty()) {
            selectedClip = -1
            playhead = 0f
        } else {
            if (list.none { it.id == selectedClip }) selectedClip = list.first().id
            playhead = playhead.coerceIn(0f, EditorSession.totalSeconds)
        }
    }

    val onSplit: () -> Unit = {
        if (!imported) {
            toast("Tambahkan video dulu lewat tombol + Media")
        } else if (selected == null) {
            toast("Pilih klip dulu di timeline")
        } else {
            val local = playhead - selected.start
            if (local < 0.3f || local > selected.length - 0.3f) {
                toast("Geser garis putih ke dalam klip terpilih, lalu coba lagi")
            } else {
                EditorSession.splitClip(selected.id, local)
                panel = null
                afterEdit()
            }
        }
    }

    val onDelete: () -> Unit = {
        if (!imported) {
            toast("Tambahkan video dulu lewat tombol + Media")
        } else if (selected == null) {
            toast("Pilih klip dulu di timeline")
        } else {
            val idx = importedClips.indexOfFirst { it.id == selected.id }
            EditorSession.deleteClip(selected.id)
            val list = EditorSession.clips
            selectedClip = list.getOrNull(minOf(idx, list.size - 1))?.id ?: -1
            panel = null
            afterEdit()
        }
    }

    val onDuplicate: () -> Unit = {
        if (!imported) {
            toast("Tambahkan video dulu lewat tombol + Media")
        } else if (selected == null) {
            toast("Pilih klip dulu di timeline")
        } else {
            val newId = EditorSession.duplicateClip(selected.id)
            if (newId != null) selectedClip = newId
            panel = null
            afterEdit()
        }
    }

    val onMove: (Int) -> Unit = { delta ->
        if (!imported) {
            toast("Tambahkan video dulu lewat tombol + Media")
        } else if (selected == null) {
            toast("Pilih klip dulu di timeline")
        } else if (EditorSession.moveClip(selected.id, delta)) {
            panel = null
            afterEdit()
        } else {
            toast("Klip sudah di ujung")
        }
    }

    val onUndo: () -> Unit = {
        if (EditorSession.undo()) afterEdit() else toast("Tidak ada yang bisa dibatalkan")
    }
    val onRedo: () -> Unit = {
        if (EditorSession.redo()) afterEdit() else toast("Tidak ada yang bisa diulang")
    }

    ZayBackground {
        Column(Modifier.fillMaxSize()) {
            // Bilah atas
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, onBack)
                Spacer(Modifier.width(12.dp))
                Text(
                    "ZAY EDITOR",
                    modifier = Modifier.weight(1f),
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
                Box {
                    val chipShape = RoundedCornerShape(12.dp)
                    Row(
                        Modifier
                            .clip(chipShape)
                            .background(NavyCardHigh)
                            .border(1.dp, StrokeSoft, chipShape)
                            .clickable { resMenu = true }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            EditorSession.resolutions[EditorSession.resolutionIndex],
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Icon(Icons.Rounded.KeyboardArrowDown, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                    DropdownMenu(expanded = resMenu, onDismissRequest = { resMenu = false }) {
                        EditorSession.resolutions.forEachIndexed { i, r ->
                            DropdownMenuItem(
                                text = { Text(r) },
                                onClick = {
                                    EditorSession.resolutionIndex = i
                                    resMenu = false
                                },
                            )
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                GradientButton(
                    text = "Export",
                    onClick = onExport,
                    height = 38.dp,
                    horizontalPadding = 18.dp,
                )
            }

            // Pratinjau: pemutar video sungguhan; gradasi saat belum ada video
            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
            val ratio = EditorSession.aspect.ratio
            val frameW = minOf(maxWidth, 250.dp * ratio)
            val frameH = frameW / ratio
            Box(
                Modifier
                    .size(frameW, frameH)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF2B1B6E), Color(0xFF8A2BE2), Color(0xFFFF7A59)),
                        ),
                    )
                    .border(1.dp, StrokeSoft, RoundedCornerShape(22.dp))
                    .clickable { togglePlay() },
                contentAlignment = Alignment.Center,
            ) {
                if (imported) {
                    AndroidView(
                        factory = { ctx ->
                            (LayoutInflater.from(ctx).inflate(R.layout.zay_player_view, null, false) as PlayerView)
                                .also { it.player = exo }
                        },
                        modifier = Modifier.matchParentSize(),
                        update = { view ->
                            // 0 = pas (seluruh video terlihat), 4 = isi (dipotong memenuhi bingkai)
                            view.resizeMode = if (EditorSession.fillFrame) 4 else 0
                        },
                    )
                }
                if (!isPlaying) {
                    Box(
                        Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                }
                Icon(
                    Icons.Rounded.Fullscreen,
                    null,
                    tint = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .size(22.dp)
                        .clickable { soon("versi berikutnya") },
                )
            }
            }

            // Kontrol transport
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "${formatTime(playhead)} / ${formatTime(total)}",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                )
                IconCircleButton(
                    Icons.Rounded.SkipPrevious,
                    onClick = {
                        playhead = videoStarts.lastOrNull { it < playhead - 0.1f } ?: 0f
                        if (imported) exo.seekToGlobal(importedClips, playhead)
                    },
                    size = 38.dp,
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(BrandGradient)
                        .clickable { togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        null,
                        tint = Color.White,
                        modifier = Modifier.size(26.dp),
                    )
                }
                Spacer(Modifier.width(8.dp))
                IconCircleButton(
                    Icons.Rounded.SkipNext,
                    onClick = {
                        playhead = videoStarts.firstOrNull { it > playhead + 0.1f } ?: total
                        if (imported) exo.seekToGlobal(importedClips, playhead)
                    },
                    size = 38.dp,
                )
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                    IconCircleButton(Icons.AutoMirrored.Rounded.Undo, onUndo, size = 36.dp)
                    Spacer(Modifier.width(6.dp))
                    IconCircleButton(Icons.AutoMirrored.Rounded.Redo, onRedo, size = 36.dp)
                }
            }

            // Info klip terpilih + tombol tambah media
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (selected != null) {
                        "Terpilih: ${selected.label} • ${String.format(Locale.US, "%.1f", selected.length)} dtk"
                    } else {
                        if (imported) "Ketuk klip untuk memilih" else "Belum ada video. Ketuk + Media."
                    },
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
                NeonChip(
                    text = "Rasio ${EditorSession.aspect.label}",
                    selected = true,
                    onClick = { panel = EditorPanel.Ratio },
                )
                Spacer(Modifier.width(8.dp))
                GradientButton(
                    text = "Media",
                    icon = Icons.Rounded.Add,
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    },
                    height = 34.dp,
                    horizontalPadding = 14.dp,
                )
            }

            // Timeline multi-layer
            TimelineView(
                clips = clips,
                selectedId = selectedClip,
                onSelect = { selectedClip = it },
                playhead = playhead,
                onSeek = { t ->
                    playhead = t.coerceIn(0f, total)
                    if (imported) exo.seekToGlobal(importedClips, playhead)
                },
                totalSec = maxOf(total, 10f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            )

            Spacer(Modifier.weight(1f))

            // Bilah alat
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                EditorPanel.entries.filter { it != EditorPanel.Ratio }.forEach { p ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(NavyCard)
                            .border(1.dp, StrokeSoft, RoundedCornerShape(14.dp))
                            .clickable { panel = p }
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(p.icon, p.label, tint = Color.White, modifier = Modifier.size(22.dp))
                        Text(p.label, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        }
    }

    val current = panel
    if (current != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { panel = null },
            sheetState = sheetState,
            containerColor = Navy,
            contentColor = TextPrimary,
            scrimColor = Color.Black.copy(alpha = 0.4f),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom))
                    .padding(bottom = 16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(current.icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        current.label,
                        modifier = Modifier.weight(1f),
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    IconCircleButton(Icons.Rounded.Close, { panel = null }, size = 36.dp)
                }
                Spacer(Modifier.height(14.dp))
                Box(
                    Modifier
                        .heightIn(max = 440.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    when (current) {
                        EditorPanel.Trim -> TrimPanel(onSplit, onDelete, onDuplicate, { onMove(-1) }, { onMove(1) })
                        EditorPanel.Music -> MusicPanel(soon)
                        EditorPanel.Teks -> TextPanel(soon)
                        EditorPanel.Effects -> EffectsPanel(soon)
                        EditorPanel.Transition -> TransitionPanel(soon)
                        EditorPanel.Sticker -> StickerPanel(soon)
                        EditorPanel.Ratio -> RatioPanel()
                    }
                }
            }
        }
    }
}

@Composable
private fun TrimPanel(
    onSplit: () -> Unit,
    onDelete: () -> Unit,
    onDuplicate: () -> Unit,
    onMoveLeft: () -> Unit,
    onMoveRight: () -> Unit,
) {
    val tools = listOf(
        Triple("Belah", Icons.Rounded.ContentCut, onSplit),
        Triple("Hapus", Icons.Rounded.Delete, onDelete),
        Triple("Duplikat", Icons.Rounded.ContentCopy, onDuplicate),
        Triple("Geser kiri", Icons.AutoMirrored.Rounded.ArrowBack, onMoveLeft),
        Triple("Geser kanan", Icons.AutoMirrored.Rounded.ArrowForward, onMoveRight),
    )
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            "Pilih klip di timeline. Untuk Belah, geser garis putih ke titik potong di dalam klip.",
            color = TextSecondary,
            fontSize = 13.sp,
        )
        SimpleGrid(tools, columns = 3) { (label, icon, action) ->
            ToolTile(icon, label, selected = false, onClick = action, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun RatioPanel() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val out = EditorSession.outputSize()
        Text(
            "Pilih rasio sesuai tujuan unggahan. Hasil ekspor: ${out.first} × ${out.second} px.",
            color = TextSecondary,
            fontSize = 13.sp,
        )
        EditorSession.aspects.forEachIndexed { index, opt ->
            val isSel = index == EditorSession.aspectIndex
            val shape = RoundedCornerShape(16.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(NavyCardHigh.copy(alpha = 0.9f))
                    .border(if (isSel) 2.dp else 1.dp, if (isSel) Color.White else StrokeSoft, shape)
                    .clickable { EditorSession.aspectIndex = index }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                    val r = opt.ratio
                    val mw = if (r >= 1f) 32.dp else 32.dp * r
                    val mh = if (r >= 1f) 32.dp / r else 32.dp
                    Box(
                        Modifier
                            .size(mw, mh)
                            .border(2.dp, if (isSel) Color.White else TextSecondary, RoundedCornerShape(4.dp)),
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("${opt.label}  ${opt.title}", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(opt.platforms, color = TextSecondary, fontSize = 12.sp)
                }
            }
        }
        Text("Cara bingkai video", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonChip("Pas (semua terlihat)", !EditorSession.fillFrame, { EditorSession.fillFrame = false })
            NeonChip("Isi (dipotong)", EditorSession.fillFrame, { EditorSession.fillFrame = true })
        }
    }
}
