package com.zay.videoeditor.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.data.DemoData
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.IconCircleButton
import com.zay.videoeditor.ui.components.NeonChip
import com.zay.videoeditor.ui.components.PanelTabs
import com.zay.videoeditor.ui.components.ProjectCard
import com.zay.videoeditor.ui.components.showSoon
import com.zay.videoeditor.ui.components.zayFieldColors
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary

@Composable
fun ProjectsScreen(
    onNewProject: () -> Unit,
    onOpenProject: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var showSearch by rememberSaveable { mutableStateOf(false) }
    var filter by rememberSaveable { mutableStateOf(0) }
    val filters = listOf("Semua", "Video", "Draf", "Favorit")

    val shown = DemoData.projects.filter { p ->
        val byFilter = when (filter) {
            1 -> p.kind == "Video"
            2 -> p.kind == "Draf"
            3 -> p.favorite
            else -> true
        }
        byFilter && p.name.contains(query, ignoreCase = true)
    }

    Column(
        modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Proyek Saya",
                color = TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconCircleButton(
                if (showSearch) Icons.Rounded.Close else Icons.Rounded.Search,
                onClick = {
                    showSearch = !showSearch
                    if (!showSearch) query = ""
                },
            )
            Spacer(Modifier.padding(horizontal = 4.dp))
            IconCircleButton(Icons.Rounded.MoreVert, onClick = { showSoon(context, "Tahap 4") })
        }

        if (showSearch) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Cari proyek") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                shape = RoundedCornerShape(18.dp),
                colors = zayFieldColors(),
            )
        }

        Spacer(Modifier.height(12.dp))
        PanelTabs(filters, filter) { filter = it }
        Spacer(Modifier.height(12.dp))

        Box(Modifier.weight(1f)) {
            if (shown.isEmpty()) {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text("Tidak ada proyek", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Coba ubah filter atau kata pencarian.", color = TextSecondary, fontSize = 13.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 8.dp),
                ) {
                    items(shown, key = { it.id }) { item ->
                        ProjectCard(item, onClick = { onOpenProject(item.id) })
                    }
                }
            }
        }

        GradientButton(
            text = "Proyek Baru",
            icon = Icons.Rounded.Add,
            onClick = onNewProject,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
        )
    }
}
