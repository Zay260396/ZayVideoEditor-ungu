package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Autorenew
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.NeonSlider
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.components.ToolTile
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary
import java.util.Locale

private val transitions: List<Pair<String, ImageVector>> = listOf(
    "Tanpa" to Icons.Rounded.Block,
    "Fade" to Icons.Rounded.BlurOn,
    "Geser" to Icons.Rounded.SwapHoriz,
    "Zoom" to Icons.Rounded.ZoomIn,
    "Putar" to Icons.Rounded.Autorenew,
    "Gelombang" to Icons.Rounded.Waves,
    "Cahaya" to Icons.Rounded.FlashOn,
    "Glitch" to Icons.Rounded.Bolt,
)

@Composable
fun TransitionPanel(onSoon: (String) -> Unit) {
    var selected by rememberSaveable { mutableStateOf(1) }
    var duration by rememberSaveable { mutableStateOf(0.6f) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            "Transisi dipasang di antara dua klip video.",
            color = TextSecondary,
            fontSize = 13.sp,
        )

        SimpleGrid(transitions.indices.toList(), columns = 4) { i ->
            ToolTile(
                icon = transitions[i].second,
                label = transitions[i].first,
                selected = selected == i,
                onClick = { selected = i },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Durasi", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(64.dp))
            NeonSlider(duration, { duration = it }, Modifier.weight(1f), valueRange = 0.2f..2f)
            Text(
                String.format(Locale.US, "%.1f dtk", duration),
                color = TextPrimary,
                fontSize = 13.sp,
                modifier = Modifier.width(60.dp),
            )
        }

        GradientButton(
            text = "Terapkan Transisi",
            onClick = { onSoon("Tahap 5") },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
