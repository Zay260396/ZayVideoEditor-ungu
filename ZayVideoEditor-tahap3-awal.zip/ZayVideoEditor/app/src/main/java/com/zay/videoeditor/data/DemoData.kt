package com.zay.videoeditor.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.zay.videoeditor.ui.theme.NeonAmber
import com.zay.videoeditor.ui.theme.NeonBlue
import com.zay.videoeditor.ui.theme.NeonMint
import com.zay.videoeditor.ui.theme.NeonOrange
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.NeonPurple

/**
 * DATA CONTOH untuk tampilan (TAHAP 1-2).
 * Akan diganti data proyek sungguhan yang disimpan di perangkat pada TAHAP 4.
 */
data class ProjectItem(
    val id: Int,
    val name: String,
    val duration: String,
    val resolution: String,
    val kind: String, // "Video" atau "Draf"
    val favorite: Boolean,
    val colors: List<Color>,
)

data class TimelineClip(
    val id: Int,
    val track: Int,
    val start: Float,
    val length: Float,
    val label: String,
)

data class TrackInfo(
    val name: String,
    val icon: ImageVector,
    val colors: List<Color>,
    val isAudio: Boolean = false,
)

object DemoData {
    val projects = listOf(
        ProjectItem(1, "Liburan Seru", "00:45", "1080p", "Video", true, listOf(Color(0xFFFF8A4D), Color(0xFF7B2FFF))),
        ProjectItem(2, "Kota Malam", "01:20", "4K", "Video", false, listOf(NeonBlue, Color(0xFF2B1B6E))),
        ProjectItem(3, "Kucing Lucu", "00:32", "1080p", "Video", true, listOf(NeonAmber, Color(0xFFE0663D))),
        ProjectItem(4, "Bunga Indah", "00:28", "720p", "Draf", false, listOf(NeonPink, Color(0xFF6A3DFF))),
        ProjectItem(5, "Senja Hari Ini", "00:50", "1080p", "Video", false, listOf(Color(0xFFFF7A59), Color(0xFF3A1B6E))),
        ProjectItem(6, "Alam Pegunungan", "01:15", "4K", "Draf", false, listOf(NeonMint, NeonBlue)),
    )
}

object DemoTimeline {
    const val TOTAL_SECONDS = 45f

    val tracks = listOf(
        TrackInfo("Video", Icons.Rounded.Visibility, listOf(NeonBlue, NeonPurple)),
        TrackInfo("Teks", Icons.Rounded.TextFields, listOf(NeonPurple, Color(0xFF7B4DFF))),
        TrackInfo("Musik", Icons.Rounded.MusicNote, listOf(Color(0xFF2E9BFF), Color(0xFF1F6FE0)), isAudio = true),
        TrackInfo("Efek", Icons.Rounded.Layers, listOf(NeonPink, Color(0xFFB83A9A))),
    )

    val clips = listOf(
        TimelineClip(1, 0, 0f, 15f, "Klip 1"),
        TimelineClip(2, 0, 15.5f, 14.5f, "Klip 2"),
        TimelineClip(3, 0, 30.5f, 14.5f, "Klip 3"),
        TimelineClip(4, 1, 5f, 20f, "Selamat Menonton"),
        TimelineClip(5, 2, 1f, 44f, "Musik Latar"),
        TimelineClip(6, 3, 10f, 12f, "Efek Cahaya"),
    )
}

/** Sesi editor sederhana yang dipakai bersama oleh Editor dan Ekspor. Diganti ViewModel pada TAHAP 4. */
object EditorSession {
    val resolutions = listOf("720P", "1080P", "4K")
    var resolutionIndex by mutableStateOf(1)
}
