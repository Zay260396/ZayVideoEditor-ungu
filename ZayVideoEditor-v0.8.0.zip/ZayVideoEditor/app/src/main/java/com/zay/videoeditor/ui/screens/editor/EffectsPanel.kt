package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.data.ImportedClip
import com.zay.videoeditor.fx.ClipFx
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.NeonSlider
import com.zay.videoeditor.ui.components.PanelTabs
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary

/**
 * Panel Efek (TAHAP 5c). Tab Filter sudah nyata: warna video berubah di pratinjau dan hasil ekspor.
 * Tab Overlay, Animasi dan Blur belum dibuat.
 */
@Composable
fun EffectsPanel(
    clip: ImportedClip?,
    onFilter: (Int) -> Unit,
    onStrength: (Float) -> Unit,
    onApplyAll: () -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf("Filter", "Overlay", "Animasi", "Blur")

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PanelTabs(tabs, tab) { tab = it }

        if (tab != 0) {
            Text(
                "Efek ${tabs[tab]} belum tersedia. Saat ini yang aktif: Filter warna dan Transisi.",
                color = TextSecondary,
                fontSize = 13.sp,
            )
            return@Column
        }

        if (clip == null) {
            Text("Pilih klip video di timeline, lalu pilih filter.", color = TextSecondary, fontSize = 13.sp)
            return@Column
        }

        SimpleGrid(ClipFx.filters.indices.toList(), columns = 4) { i ->
            val item = ClipFx.filters[i]
            val isSelected = clip.filter == i
            val shape = RoundedCornerShape(16.dp)
            Column(
                Modifier.clickable { onFilter(i) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(shape)
                        .background(Brush.linearGradient(listOf(item.top, item.bottom)))
                        .then(
                            if (isSelected) {
                                Modifier.border(3.dp, BrandGradient, shape)
                            } else {
                                Modifier.border(1.dp, StrokeSoft, shape)
                            },
                        ),
                ) {}
                Text(
                    item.name,
                    color = if (isSelected) TextPrimary else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        if (clip.filter > 0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Atur Intensitas", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(104.dp))
                NeonSlider(clip.filterStrength, onStrength, Modifier.weight(1f))
                Text("${(clip.filterStrength * 100).toInt()}%", color = TextPrimary, fontSize = 13.sp, modifier = Modifier.width(44.dp))
            }
        }

        GradientButton(
            text = "Terapkan ke Semua Klip",
            onClick = onApplyAll,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
