package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.NeonSlider
import com.zay.videoeditor.ui.components.PanelTabs
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.theme.NeonAmber
import com.zay.videoeditor.ui.theme.NeonBlue
import com.zay.videoeditor.ui.theme.NeonMint
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.NeonPurple
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary

private data class FxItem(val name: String, val a: Color, val b: Color)

// Pratinjau gradasi sebagai wakil tampilan filter. Pengolahan visual sungguhan dibangun di TAHAP 5.
private val filters = listOf(
    FxItem("Vintage", Color(0xFFE8B98A), Color(0xFF8A5A44)),
    FxItem("Dreamy", Color(0xFF9FD8FF), Color(0xFFD9A6FF)),
    FxItem("Neon", NeonPink, NeonPurple),
    FxItem("Bokeh", NeonAmber, Color(0xFF4DAA6E)),
    FxItem("Glitch", NeonBlue, NeonPink),
    FxItem("Film", Color(0xFF7FA8C9), Color(0xFF2B3A55)),
    FxItem("Glow", Color(0xFFFFFFFF), NeonBlue),
    FxItem("Sepia", Color(0xFFD9B88F), Color(0xFF6B4A2E)),
)

private val overlays = listOf(
    FxItem("Debu", Color(0xFFBBBBBB), Color(0xFF444444)),
    FxItem("Bintang", NeonAmber, NeonPurple),
    FxItem("Hujan", NeonBlue, Color(0xFF2B1B6E)),
    FxItem("Kilau", Color.White, NeonPink),
)

private val animations = listOf(
    FxItem("Getar", NeonPink, NeonPurple),
    FxItem("Denyut", NeonPurple, NeonBlue),
    FxItem("Zoom", NeonBlue, NeonMint),
    FxItem("Putar", NeonAmber, NeonPink),
)

private val blurs = listOf(
    FxItem("Lembut", Color(0xFF9FB4FF), Color(0xFF5B6BC0)),
    FxItem("Radial", NeonPurple, Color(0xFF2B1B6E)),
    FxItem("Gerak", NeonBlue, NeonPurple),
    FxItem("Tepi", NeonMint, Color(0xFF1F6FE0)),
)

@Composable
fun EffectsPanel(onSoon: (String) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var selected by rememberSaveable { mutableStateOf(0) }
    var intensity by rememberSaveable { mutableStateOf(0.7f) }

    val tabs = listOf("Filter", "Overlay", "Animasi", "Blur")
    val items = when (tab) {
        1 -> overlays
        2 -> animations
        3 -> blurs
        else -> filters
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PanelTabs(tabs, tab) {
            tab = it
            selected = 0
        }

        SimpleGrid(items.indices.toList(), columns = 4) { i ->
            val item = items[i]
            val isSelected = selected == i
            val shape = RoundedCornerShape(16.dp)
            Column(
                Modifier.clickable { selected = i },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(shape)
                        .background(Brush.linearGradient(listOf(item.a, item.b)))
                        .then(
                            if (isSelected) {
                                Modifier.border(3.dp, BrandGradient, shape)
                            } else {
                                Modifier.border(1.dp, StrokeSoft, shape)
                            },
                        ),
                ) {}
                Text(
                    item.name,
                    color = if (isSelected) TextPrimary else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Atur Intensitas", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(104.dp))
            NeonSlider(intensity, { intensity = it }, Modifier.weight(1f))
            Text("${(intensity * 100).toInt()}%", color = TextPrimary, fontSize = 13.sp, modifier = Modifier.width(44.dp))
        }

        GradientButton(
            text = "Terapkan ke Klip",
            onClick = { onSoon("Tahap 5") },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
