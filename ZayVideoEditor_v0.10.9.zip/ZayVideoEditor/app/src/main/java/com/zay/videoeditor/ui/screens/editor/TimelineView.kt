package com.zay.videoeditor.ui.screens.editor

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.data.DemoTimeline
import com.zay.videoeditor.data.TimelineClip
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.theme.Navy
import com.zay.videoeditor.ui.theme.NavyCard
import com.zay.videoeditor.ui.theme.NavyCardHigh
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.sin

/** Sumber gambar kecil (thumbnail) sebuah klip video: berkas dan detik awal potongannya. */
data class ThumbSource(val uri: Uri, val trimStartSec: Float)

// Warna mengikuti palet ZAY (navy + ungu neon), bukan abu-abu CapCut.
private val TrackBg = NavyCard
private val TileBg = NavyCardHigh
private val Muted = TextSecondary
private val LabelBg = Navy.copy(alpha = 0.92f)

/**
 * Timeline multi-layer gaya CapCut: garis putih (playhead) tetap di tengah layar dan
 * timeline yang digeser di bawahnya. Menggeser timeline = memindah posisi putar.
 * Urutan baris dari atas: Video (dengan thumbnail), Musik, Teks, lalu Efek (hanya bila ada).
 */
@Composable
fun TimelineView(
    clips: List<TimelineClip>,
    selectedId: Int,
    onSelect: (Int) -> Unit,
    playhead: Float,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    dpPerSec: Float = 44f,
    totalSec: Float = DemoTimeline.TOTAL_SECONDS,
    /** Mulai menyeret item [id] (dipakai untuk mencatat undo). */
    onDragStart: (Int) -> Unit = {},
    /** Geser seluruh item [id] sebesar delta detik (teks, stiker, musik). */
    onDragBody: (Int, Float) -> Unit = { _, _ -> },
    /** Tarik tepi item: (id, tepiKiri, delta detik). Video, teks, stiker. */
    onDragEdge: (Int, Boolean, Float) -> Unit = { _, _, _ -> },
    /** Hapus item [id] lewat tombol X di atas item teks/musik/efek yang terpilih. */
    onDeleteItem: (Int) -> Unit = {},
    /** Bila diisi, tombol + muncul di ujung lapisan video untuk menambah media. */
    onAddMedia: (() -> Unit)? = null,
    onAddAudio: () -> Unit = {},
    onAddText: () -> Unit = {},
    onCover: () -> Unit = {},
    timeCurrent: String = "00:00",
    timeTotal: String = "00:00",
    /** Id klip video -> sumber thumbnail. */
    videoSources: Map<Int, ThumbSource> = emptyMap(),
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val startCb = rememberUpdatedState(onDragStart)
    val bodyCb = rememberUpdatedState(onDragBody)
    val edgeCb = rememberUpdatedState(onDragEdge)
    val playheadNow = rememberUpdatedState(playhead)
    val seekNow = rememberUpdatedState(onSeek)
    val pxPerSecNow = with(density) { dpPerSec.dp.toPx() }
    val tracks = DemoTimeline.tracks
    val rulerH = 28.dp
    val rowH: (Int) -> Dp = { ti -> if (ti == 0) 48.dp else 34.dp }
    // Urutan tampil: Video (0), Musik (2), Teks (1), Efek (3)
    val order = listOf(0, 2, 1, 3)

    // Geser timeline dengan jari -> posisi putar ikut. Posisi putar berubah (diputar/lompat) -> timeline ikut bergeser.
    LaunchedEffect(scroll, pxPerSecNow, totalSec) {
        snapshotFlow { scroll.value }.collect { v ->
            if (scroll.isScrollInProgress && abs(v - playheadNow.value * pxPerSecNow) > 1.5f) {
                seekNow.value((v / pxPerSecNow).coerceIn(0f, totalSec))
            }
        }
    }
    LaunchedEffect(playhead, pxPerSecNow, scroll.maxValue) {
        if (!scroll.isScrollInProgress) {
            val target = (playhead * pxPerSecNow).roundToInt().coerceAtLeast(0)
            if (scroll.value != target) scroll.scrollTo(target)
        }
    }

    // Item yang waktunya bertumpuk di satu lapisan ditaruh di baris (lane) berbeda, maksimal 3 baris per lapisan.
    val lanes = assignLanes(clips)
    val laneCounts = tracks.indices.map { ti ->
        val items = clips.filter { it.track == ti }
        when {
            items.isNotEmpty() -> items.maxOf { lanes[it.id] ?: 0 } + 1
            ti == 3 -> 0 // baris Efek disembunyikan bila kosong
            else -> 1 // baris kosong Musik/Teks menampilkan "+ Tambahkan ..."
        }
    }
    val trackTops = tracks.indices.map { ti ->
        order.takeWhile { it != ti }.fold(0.dp) { acc, o -> acc + rowH(o) * laneCounts[o] }
    }
    val bodyH = order.fold(0.dp) { acc, o -> acc + rowH(o) * laneCounts[o] }

    BoxWithConstraints(modifier) {
        val halfW = maxWidth / 2
        val contentW = (totalSec * dpPerSec).dp
        val videoEnd = clips.filter { it.track == 0 }.maxOfOrNull { it.start + it.length } ?: 0f
        val firstVideo = clips.firstOrNull { it.track == 0 }
        val scrollDp = with(density) { scroll.value.toDp() }

        Box(Modifier.fillMaxSize().horizontalScroll(scroll)) {
            // Ruang kosong setengah layar di kiri dan kanan supaya awal/akhir klip bisa sampai ke garis tengah
            Box(Modifier.width(halfW * 2 + contentW).height(rulerH + bodyH)) {
                Box(
                    Modifier
                        .offset(x = halfW)
                        .width(contentW)
                        .height(rulerH + bodyH)
                        .pointerInput(dpPerSec, totalSec) {
                            detectTapGestures { offset ->
                                val pxPerSec = with(density) { dpPerSec.dp.toPx() }
                                onSeek((offset.x / pxPerSec).coerceIn(0f, totalSec))
                            }
                        },
                ) {
                    // Penggaris waktu: label 00:01 tiap detik, titik di tengah-tengahnya
                    (0..totalSec.toInt()).forEach { s ->
                        Text(
                            String.format("%02d:%02d", s / 60, s % 60),
                            color = Muted,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            modifier = Modifier
                                .offset(x = (s * dpPerSec).dp - 20.dp, y = 8.dp)
                                .width(40.dp),
                        )
                        Box(
                            Modifier
                                .offset(x = ((s + 0.5f) * dpPerSec).dp - 1.5.dp, y = 13.dp)
                                .size(3.dp)
                                .clip(CircleShape)
                                .background(Muted.copy(alpha = 0.7f)),
                        )
                    }

                    // Baris kosong Musik dan Teks: "+ Tambahkan ..." (teksnya ikut menempel di kiri saat digeser)
                    listOf(2 to "Tambahkan audio", 1 to "Tambahkan teks").forEach { (ti, text) ->
                        if (clips.none { it.track == ti }) {
                            val labelX = maxOf(10.dp, 64.dp - halfW + scrollDp)
                            Box(
                                Modifier
                                    .offset(x = 0.dp, y = rulerH + trackTops[ti] + 3.dp)
                                    .width(contentW)
                                    .height(rowH(ti) - 6.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(TrackBg)
                                    .clickable { if (ti == 2) onAddAudio() else onAddText() },
                            ) {
                                Row(
                                    Modifier
                                        .align(Alignment.CenterStart)
                                        .offset(x = labelX),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Icon(Icons.Rounded.Add, null, tint = Muted, modifier = Modifier.size(16.dp))
                                    Text(
                                        text,
                                        color = Muted,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        modifier = Modifier.padding(start = 4.dp),
                                    )
                                }
                            }
                        }
                    }

                    // Klip
                    clips.forEach { item ->
                        val track = tracks[item.track]
                        val selected = item.id == selectedId
                        val isVideo = item.track == 0
                        val rh = rowH(item.track)
                        val clipShape = RoundedCornerShape(if (isVideo) 6.dp else 8.dp)
                        Box(
                            Modifier
                                .offset(
                                    x = (item.start * dpPerSec).dp,
                                    y = rulerH + trackTops[item.track] + rh * (lanes[item.id] ?: 0) + 3.dp,
                                )
                                .width((item.length * dpPerSec).dp)
                                .height(rh - 6.dp)
                                .clip(clipShape)
                                .background(if (isVideo) TileBg else Color.Transparent)
                                .then(
                                    if (isVideo) Modifier else Modifier.background(Brush.horizontalGradient(track.colors)),
                                )
                                .clickable { onSelect(item.id) }
                                .then(
                                    if (selected && (item.track == 1 || item.track == 2 || (item.track == 3 && item.id < 1_000_000))) {
                                        Modifier.pointerInput(item.id, pxPerSecNow) {
                                            detectDragGestures(
                                                onDragStart = { startCb.value(item.id) },
                                            ) { change, drag ->
                                                change.consume()
                                                bodyCb.value(item.id, drag.x / pxPerSecNow)
                                            }
                                        }
                                    } else {
                                        Modifier
                                    },
                                ),
                            contentAlignment = Alignment.CenterStart,
                        ) {
                            if (isVideo) {
                                VideoThumbs(
                                    lengthSec = item.length,
                                    src = videoSources[item.id],
                                    dpPerSec = dpPerSec,
                                    modifier = Modifier.matchParentSize(),
                                    cellSize = rh - 6.dp,
                                )
                            } else {
                                if (track.isAudio) {
                                    Canvas(Modifier.matchParentSize()) {
                                        val barW = 3.dp.toPx()
                                        val gap = 3.dp.toPx()
                                        var x = 0f
                                        var i = 0
                                        while (x < size.width) {
                                            val h = (0.25f + 0.6f * abs(sin(i * 0.7f))) * size.height
                                            drawRoundRect(
                                                color = Color.White.copy(alpha = 0.35f),
                                                topLeft = Offset(x, (size.height - h) / 2f),
                                                size = Size(barW, h),
                                                cornerRadius = CornerRadius(barW / 2f),
                                            )
                                            x += barW + gap
                                            i++
                                        }
                                    }
                                }
                                Text(
                                    item.label,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                )
                            }
                            if (selected) {
                                Box(Modifier.matchParentSize().border(2.dp, Color.White, clipShape))
                            }
                        }
                    }

                    // Item terpilih: pegangan tepi (perpanjang/perpendek). Item selain video juga punya tombol X.
                    clips.firstOrNull { it.id == selectedId && (it.track <= 2 || it.id < 1_000_000) }?.let { item ->
                        val rh = rowH(item.track)
                        val itemTop = rulerH + trackTops[item.track] + rh * (lanes[item.id] ?: 0) + 3.dp
                        val itemH = rh - 6.dp
                        if (item.track == 0 || item.track == 1 || item.track == 3) {
                            listOf(true, false).forEach { isLeft ->
                                Box(
                                    Modifier
                                        .offset(
                                            x = if (isLeft) (item.start * dpPerSec).dp - 2.dp else ((item.start + item.length) * dpPerSec).dp - 14.dp,
                                            y = itemTop,
                                        )
                                        .width(16.dp)
                                        .height(itemH)
                                        .pointerInput(item.id, isLeft, pxPerSecNow) {
                                            detectDragGestures(
                                                onDragStart = { startCb.value(item.id) },
                                            ) { change, drag ->
                                                change.consume()
                                                edgeCb.value(item.id, isLeft, drag.x / pxPerSecNow)
                                            }
                                        },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Box(
                                        Modifier
                                            .width(10.dp)
                                            .height(itemH)
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(Color.White),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Box(
                                            Modifier
                                                .width(2.dp)
                                                .height(14.dp)
                                                .background(Color(0xFF2B1B6E)),
                                        )
                                    }
                                }
                            }
                        }
                        if (item.track != 0) {
                            Box(
                                Modifier
                                    .offset(
                                        x = ((item.start + item.length / 2f) * dpPerSec).dp - 12.dp,
                                        y = itemTop - 12.dp,
                                    )
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(NeonPink)
                                    .border(1.5.dp, Color.White, CircleShape)
                                    .clickable { onDeleteItem(item.id) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Rounded.Close, "Hapus", tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }

                // Kotak Sampul di kiri awal video (ikut bergeser bersama timeline)
                Box(
                    Modifier
                        .offset(x = halfW - 54.dp, y = rulerH + 3.dp)
                        .size(width = 46.dp, height = rowH(0) - 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TileBg)
                        .clickable { onCover() },
                    contentAlignment = Alignment.Center,
                ) {
                    if (firstVideo != null) {
                        VideoThumbs(
                            lengthSec = 0.01f,
                            src = videoSources[firstVideo.id],
                            dpPerSec = dpPerSec,
                            modifier = Modifier.matchParentSize(),
                            cellSize = rowH(0) - 6.dp,
                            single = true,
                        )
                        Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.45f)))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.Edit, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Text("Sampul", color = Color.White, fontSize = 9.sp, maxLines = 1)
                    }
                }

                // Tombol + di ujung lapisan video
                if (onAddMedia != null) {
                    Box(
                        Modifier
                            .offset(x = halfW + (videoEnd * dpPerSec).dp + 6.dp, y = rulerH + 3.dp)
                            .size(width = 44.dp, height = rowH(0) - 6.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrandGradient)
                            .clickable { onAddMedia() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Add, "Tambah media", tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }

        // Ikon baris Musik dan Teks: menempel di kiri layar saat timeline digeser
        listOf(2 to Icons.Outlined.MusicNote, 1 to Icons.Outlined.TextFields).forEach { (ti, icon) ->
            if (laneCounts[ti] > 0) {
                val iconX = maxOf(14.dp, halfW - scrollDp - 40.dp)
                Box(
                    Modifier
                        .offset(x = iconX, y = rulerH + trackTops[ti] + 4.dp)
                        .size(28.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(TileBg)
                        .clickable { if (ti == 2) onAddAudio() else onAddText() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(icon, null, tint = Muted, modifier = Modifier.size(16.dp))
                }
            }
        }

        // Waktu sekarang / total di kiri atas penggaris
        Row(
            Modifier
                .align(Alignment.TopStart)
                .height(rulerH)
                .background(LabelBg)
                .padding(start = 14.dp, end = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(timeCurrent, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(" / $timeTotal", color = Muted, fontSize = 12.sp)
        }

        // Garis putih tetap di tengah (hanya tampilan; tidak menghalangi sentuhan)
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .width(2.dp)
                .fillMaxHeight()
                .background(Color.White),
        )
    }
}

/**
 * Deretan thumbnail persegi sepanjang klip, diambil dari frame video secara bertahap di latar belakang.
 * [single] = hanya satu gambar yang memenuhi seluruh ruang (untuk kotak Sampul).
 */
@Composable
private fun VideoThumbs(
    lengthSec: Float,
    src: ThumbSource?,
    dpPerSec: Float,
    modifier: Modifier = Modifier,
    cellSize: Dp = 42.dp,
    single: Boolean = false,
) {
    val context = LocalContext.current
    val cells = if (single) 1 else ceil((lengthSec * dpPerSec) / cellSize.value).toInt().coerceIn(1, 80)
    val bitmaps = remember(src?.uri, src?.trimStartSec, cells) { mutableStateMapOf<Int, ImageBitmap>() }

    LaunchedEffect(src?.uri, src?.trimStartSec, cells) {
        if (src == null) return@LaunchedEffect
        delay(250) // jeda singkat supaya menarik tepi klip tidak memuat ulang di tiap gerakan
        withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, src.uri)
                for (i in 0 until cells) {
                    val t = if (single) src.trimStartSec else src.trimStartSec + (i + 0.5f) * lengthSec / cells
                    val frame = r.getFrameAtTime((t * 1_000_000f).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: continue
                    val targetH = 120
                    val targetW = maxOf(1, frame.width * targetH / maxOf(1, frame.height))
                    val small = Bitmap.createScaledBitmap(frame, targetW, targetH, true)
                    if (small !== frame) frame.recycle()
                    bitmaps[i] = small.asImageBitmap()
                }
            } catch (_: Exception) {
                // Thumbnail gagal dibuat: biarkan kotak abu-abu.
            } finally {
                try {
                    r.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    val cellW = (lengthSec * dpPerSec / cells).dp
    Row(modifier) {
        for (i in 0 until cells) {
            val cellMod = if (single) Modifier.fillMaxSize() else Modifier.width(cellW).fillMaxHeight()
            Box(cellMod) {
                val bm = bitmaps[i]
                if (bm != null) {
                    Image(
                        bitmap = bm,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }
    }
}

/** Nomor baris (0..2) tiap item di lapisannya: item yang waktunya bertumpuk dipindah ke baris berikutnya. */
private fun assignLanes(clips: List<TimelineClip>): Map<Int, Int> {
    val result = HashMap<Int, Int>()
    for ((_, group) in clips.groupBy { it.track }) {
        val laneEnds = ArrayList<Float>()
        for (item in group.sortedBy { it.start }) {
            var lane = laneEnds.indexOfFirst { it <= item.start + 0.001f }
            if (lane < 0) {
                laneEnds.add(item.start + item.length)
                lane = laneEnds.size - 1
            } else {
                laneEnds[lane] = item.start + item.length
            }
            result[item.id] = minOf(lane, 2)
        }
    }
    return result
}
