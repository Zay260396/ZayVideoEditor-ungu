package com.zay.videoeditor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.ZayBackground
import com.zay.videoeditor.ui.theme.NavyCard
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextSecondary

private data class NavItem(val label: String, val icon: ImageVector)

private val navItems = listOf(
    NavItem("Beranda", Icons.Rounded.Home),
    NavItem("Proyek", Icons.Rounded.Folder),
    NavItem("Template", Icons.Rounded.Dashboard),
    NavItem("Profil", Icons.Rounded.Person),
)

@Composable
fun MainScreen(onNewProject: () -> Unit, onOpenProject: (Int) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }

    ZayBackground {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(
                        onNewProject = onNewProject,
                        onOpenProject = onOpenProject,
                        onSeeAll = { tab = 1 },
                        onSettings = { tab = 3 },
                    )
                    1 -> ProjectsScreen(onNewProject = onNewProject, onOpenProject = onOpenProject)
                    2 -> TemplateScreen()
                    else -> ProfileScreen()
                }
            }
            ZayBottomBar(selected = tab, onSelect = { tab = it })
        }
    }
}

@Composable
private fun ZayBottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(shape)
            .background(NavyCard)
            .border(1.dp, StrokeSoft, shape)
            .padding(horizontal = 6.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        navItems.forEachIndexed { index, item ->
            val isSelected = index == selected
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onSelect(index) }
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .then(
                            if (isSelected) Modifier.background(BrandGradient) else Modifier,
                        )
                        .padding(horizontal = 16.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        item.icon,
                        item.label,
                        tint = if (isSelected) Color.White else TextSecondary,
                        modifier = Modifier.size(22.dp),
                    )
                }
                Text(
                    item.label,
                    color = if (isSelected) Color.White else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                )
            }
        }
    }
}
