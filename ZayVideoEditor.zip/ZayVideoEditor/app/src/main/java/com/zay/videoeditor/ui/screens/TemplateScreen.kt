package com.zay.videoeditor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.size
import com.zay.videoeditor.ui.components.PanelTabs
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.components.showSoon
import com.zay.videoeditor.ui.theme.NeonAmber
import com.zay.videoeditor.ui.theme.NeonBlue
import com.zay.videoeditor.ui.theme.NeonMint
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.NeonPurple
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary

private data class TemplateItem(val title: String, val tag: String, val colors: List<Color>)

private val templates = listOf(
    TemplateItem("Vlog Harian", "Vlog", listOf(NeonBlue, NeonPurple)),
    TemplateItem("Beat Neon", "Musik", listOf(NeonPurple, NeonPink)),
    TemplateItem("Promosi Produk", "Bisnis", listOf(NeonAmber, Color(0xFFE0663D))),
    TemplateItem("Liburan Cepat", "Vlog", listOf(NeonMint, NeonBlue)),
    TemplateItem("Lirik Estetik", "Musik", listOf(NeonPink, Color(0xFF6A3DFF))),
    TemplateItem("Slide Katalog", "Bisnis", listOf(Color(0xFFFF7A59), Color(0xFF3A1B6E))),
)

@Composable
fun TemplateScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val tabs = listOf("Semua", "Vlog", "Musik", "Bisnis")
    var tab by rememberSaveable { mutableStateOf(0) }
    val shown = templates.filter { tab == 0 || it.tag == tabs[tab] }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 16.dp),
    ) {
        Text("Template", color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Mulai lebih cepat dengan kerangka siap pakai", color = TextSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        PanelTabs(tabs, tab) { tab = it }
        Spacer(Modifier.height(14.dp))
        SimpleGrid(shown, columns = 2, spacing = 12.dp) { item ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(item.colors))
                    .clickable { showSoon(context, "Tahap 5") }
                    .padding(14.dp),
            ) {
                Icon(
                    Icons.Rounded.Movie,
                    null,
                    tint = Color.White.copy(alpha = 0.3f),
                    modifier = Modifier
                        .size(56.dp)
                        .align(Alignment.Center),
                )
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text(item.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(item.tag, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                }
            }
        }
    }
}
