package com.zay.videoeditor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.data.DemoData
import com.zay.videoeditor.ui.components.IconCircleButton
import com.zay.videoeditor.ui.components.ProjectMini
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.components.ZayLogo
import com.zay.videoeditor.ui.theme.NeonBlue
import com.zay.videoeditor.ui.theme.NeonOrange
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.NeonPurple
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary

private data class HomeTool(val label: String, val icon: ImageVector, val colors: List<Color>)

private val homeTools = listOf(
    HomeTool("Edit\nVideo", Icons.Rounded.ContentCut, listOf(Color(0xFF8B5CFF), Color(0xFF6A3DFF))),
    HomeTool("Musik", Icons.Rounded.MusicNote, listOf(Color(0xFF2E9BFF), Color(0xFF1F6FE0))),
    HomeTool("Teks", Icons.Rounded.TextFields, listOf(Color(0xFFE04BB0), Color(0xFFB83A9A))),
    HomeTool("Efek", Icons.Rounded.Star, listOf(NeonOrange, Color(0xFFEE7A2E))),
    HomeTool("Transisi", Icons.Rounded.SwapHoriz, listOf(Color(0xFF9B5CFF), Color(0xFF6B3FE0))),
    HomeTool("Stiker", Icons.Rounded.EmojiEmotions, listOf(Color(0xFF4A6BFF), Color(0xFF6A4DFF))),
)

@Composable
fun HomeScreen(
    onNewProject: () -> Unit,
    onOpenProject: (Int) -> Unit,
    onSeeAll: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        // Header: logo + nama + pengaturan
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            ZayLogo(50.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "ZAY",
                    color = TextPrimary,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontStyle = FontStyle.Italic,
                    lineHeight = 30.sp,
                )
                Text("VIDEO EDITOR", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            IconCircleButton(Icons.Rounded.Settings, onSettings)
        }

        Text("Create • Edit • Inspire", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)

        // Hero
        Box(
            Modifier
                .fillMaxWidth()
                .height(210.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF2B1B6E), Color(0xFF5B2AA8), Color(0xFF8A3FD8)),
                    ),
                ),
        ) {
            // Ilustrasi pengganti foto: lingkaran bercahaya + headphone
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .size(210.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(NeonPink.copy(alpha = 0.55f), Color.Transparent),
                            ),
                        ),
                )
                Box(
                    Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(NeonPink.copy(alpha = 0.85f), NeonPurple))),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Headphones, null, tint = Color.White, modifier = Modifier.size(64.dp))
                }
            }
            Column(
                Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .padding(start = 20.dp, top = 24.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "Turn your\nmoments into\nmasterpieces ✨",
                    color = Color.White,
                    fontSize = 24.sp,
                    lineHeight = 30.sp,
                    fontFamily = FontFamily.Cursive,
                    fontStyle = FontStyle.Italic,
                    fontWeight = FontWeight.Bold,
                )
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.14f))
                        .border(1.dp, NeonBlue.copy(alpha = 0.8f), RoundedCornerShape(50))
                        .clickable(onClick = onNewProject)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Mulai Sekarang", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowForward,
                        null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }

        // Grid alat 3x2
        SimpleGrid(homeTools, columns = 3, spacing = 12.dp) { tool ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.05f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.verticalGradient(tool.colors))
                    .clickable(onClick = onNewProject)
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(tool.icon, null, tint = Color.White, modifier = Modifier.size(34.dp))
                Spacer(Modifier.height(6.dp))
                Text(
                    tool.label,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 15.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }

        // Proyek Saya
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Proyek Saya",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onSeeAll)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text("Lihat Semua", color = TextSecondary, fontSize = 12.sp)
                Icon(
                    Icons.AutoMirrored.Rounded.ArrowForward,
                    null,
                    tint = TextSecondary,
                    modifier = Modifier.size(14.dp),
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DemoData.projects.take(3).forEach { item ->
                ProjectMini(item, onClick = { onOpenProject(item.id) }, modifier = Modifier.weight(1f))
            }
        }
    }
}
