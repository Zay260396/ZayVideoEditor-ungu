package com.zay.videoeditor.data

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.Color
import com.zay.videoeditor.ui.theme.NeonAmber
import com.zay.videoeditor.ui.theme.NeonBlue
import com.zay.videoeditor.ui.theme.NeonMint
import com.zay.videoeditor.ui.theme.NeonOrange
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.NeonPurple
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Penyimpanan proyek di perangkat (TAHAP 4b).
 * - Proyek: filesDir/projects/<id>.json
 * - Salinan video: filesDir/media/  (supaya proyek tetap bisa dibuka walau file asli dipindah/dihapus)
 */
object ProjectStore {
    /** Daftar proyek untuk Beranda dan halaman Proyek. */
    val projects = mutableStateListOf<ProjectItem>()

    private val palettes = listOf(
        listOf(NeonOrange, NeonPurple),
        listOf(NeonBlue, Color(0xFF2B1B6E)),
        listOf(NeonAmber, Color(0xFFE0663D)),
        listOf(NeonPink, Color(0xFF6A3DFF)),
        listOf(NeonMint, NeonBlue),
    )

    private fun projectDir(context: Context): File = File(context.filesDir, "projects").also { it.mkdirs() }

    fun mediaDir(context: Context): File = File(context.filesDir, "media").also { it.mkdirs() }

    private fun fileOf(context: Context, id: Int): File = File(projectDir(context), "$id.json")

    private fun newId(): Int = (System.currentTimeMillis() / 1000L).toInt()

    private fun defaultName(): String =
        "Proyek " + SimpleDateFormat("d MMM HH.mm", Locale("id", "ID")).format(Date())

    private fun formatDuration(sec: Float): String {
        val total = sec.toInt()
        return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
    }

    // ---------------- Daftar ----------------

    fun refresh(context: Context) {
        val files = projectDir(context).listFiles()?.filter { it.extension == "json" } ?: emptyList()
        val items = files
            .sortedByDescending { it.lastModified() }
            .mapNotNull { readItem(it) }
        projects.clear()
        projects.addAll(items)
    }

    private fun readItem(file: File): ProjectItem? {
        return try {
            val o = JSONObject(file.readText())
            val id = o.getInt("id")
            val clips = o.optJSONArray("clips") ?: JSONArray()
            var total = 0f
            for (i in 0 until clips.length()) {
                val c = clips.getJSONObject(i)
                total += (c.getDouble("trimEnd") - c.getDouble("trimStart")).toFloat()
            }
            val resIdx = o.optInt("resolution", 1).coerceIn(0, EditorSession.resolutions.size - 1)
            ProjectItem(
                id = id,
                name = o.optString("name", "Proyek"),
                duration = formatDuration(total),
                resolution = EditorSession.resolutions[resIdx],
                kind = if (clips.length() > 0) "Video" else "Draf",
                favorite = o.optBoolean("favorite", false),
                colors = palettes[Math.floorMod(id, palettes.size)],
            )
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Buka / simpan ----------------

    /** Mulai proyek kosong yang baru. File baru dibuat saat video pertama ditambahkan. */
    fun openNew() {
        EditorSession.start(newId(), defaultName(), 1, false, emptyList())
    }

    /** Buka proyek tersimpan. False bila file proyek tidak bisa dibaca. */
    fun open(context: Context, id: Int): Boolean {
        return try {
            val o = JSONObject(fileOf(context, id).readText())
            val list = mutableListOf<ImportedClip>()
            val arr = o.optJSONArray("clips") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val file = File(c.getString("path"))
                if (!file.exists()) continue
                val source = c.getDouble("source").toFloat()
                list.add(
                    ImportedClip(
                        id = EditorSession.nextId(),
                        uri = Uri.fromFile(file),
                        name = c.optString("name", "Klip"),
                        sourceDurationSec = source,
                        trimStartSec = c.getDouble("trimStart").toFloat(),
                        trimEndSec = c.getDouble("trimEnd").toFloat(),
                    ),
                )
            }
            EditorSession.start(
                id = o.getInt("id"),
                name = o.optString("name", defaultName()),
                resolution = o.optInt("resolution", 1).coerceIn(0, EditorSession.resolutions.size - 1),
                fav = o.optBoolean("favorite", false),
                list = list,
                aspect = o.optInt("aspect", 0),
                fill = o.optBoolean("fill", false),
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Simpan proyek yang sedang dibuka di editor. */
    fun saveCurrent(context: Context) {
        val id = EditorSession.projectId
        if (id == 0) return
        val file = fileOf(context, id)
        if (EditorSession.clips.isEmpty() && !file.exists()) return
        try {
            val arr = JSONArray()
            for (c in EditorSession.clips.toList()) {
                arr.put(
                    JSONObject().apply {
                        put("path", c.uri.path ?: "")
                        put("name", c.name)
                        put("source", c.sourceDurationSec.toDouble())
                        put("trimStart", c.trimStartSec.toDouble())
                        put("trimEnd", c.trimEndSec.toDouble())
                    },
                )
            }
            val o = JSONObject().apply {
                put("id", id)
                put("name", EditorSession.projectName)
                put("resolution", EditorSession.resolutionIndex)
                put("favorite", EditorSession.favorite)
                put("aspect", EditorSession.aspectIndex)
                put("fill", EditorSession.fillFrame)
                put("clips", arr)
            }
            file.writeText(o.toString())
        } catch (e: Exception) {
            // gagal menyimpan: abaikan, percobaan berikutnya akan menimpa
        }
    }

    // ---------------- Kelola ----------------

    fun setFavorite(context: Context, id: Int, value: Boolean) {
        try {
            val f = fileOf(context, id)
            val o = JSONObject(f.readText())
            o.put("favorite", value)
            f.writeText(o.toString())
        } catch (e: Exception) {
            // abaikan
        }
        refresh(context)
    }

    /** Ganti nama proyek yang tersimpan di perangkat. */
    fun rename(context: Context, id: Int, newName: String) {
        val name = newName.trim()
        if (name.isEmpty()) return
        try {
            val f = fileOf(context, id)
            val o = JSONObject(f.readText())
            o.put("name", name)
            f.writeText(o.toString())
        } catch (e: Exception) {
            // abaikan
        }
        refresh(context)
    }

    /** Hapus proyek beserta salinan video yang tidak dipakai proyek lain. */
    fun delete(context: Context, id: Int) {
        val target = fileOf(context, id)
        val mine = pathsOf(target)
        target.delete()
        val others = (projectDir(context).listFiles() ?: emptyArray())
            .filter { it.extension == "json" }
            .flatMap { pathsOf(it) }
            .toSet()
        for (p in mine) {
            if (p !in others) File(p).delete()
        }
        refresh(context)
    }

    private fun pathsOf(file: File): List<String> {
        return try {
            val arr = JSONObject(file.readText()).optJSONArray("clips") ?: return emptyList()
            (0 until arr.length()).map { arr.getJSONObject(it).getString("path") }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
