package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.PanelTabs
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.theme.NavyCardHigh
import com.zay.videoeditor.ui.theme.StrokeSoft

private val categories = listOf("Populer", "Emoji", "Alam", "Dekorasi")

private val stickers = listOf(
    listOf("😀", "😍", "🔥", "💜", "✨", "🎉", "👍", "💯", "🌈", "⭐", "😎", "🥳"),
    listOf("😂", "🥰", "😭", "😡", "🤯", "😴", "🤔", "🙌", "👏", "🙏", "💪", "👀"),
    listOf("🌸", "🌙", "☀", "🌊", "🍀", "🦋", "🌺", "⚡", "❄", "🌴", "🍃", "🌟"),
    listOf("💖", "💫", "🎈", "🎀", "🎵", "🎬", "📸", "🏆", "👑", "💎", "🎶", "🎁"),
)

@Composable
fun StickerPanel(onSoon: (String) -> Unit) {
    var category by rememberSaveable { mutableStateOf(0) }
    var selected by rememberSaveable { mutableStateOf(-1) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PanelTabs(categories, category) {
            category = it
            selected = -1
        }

        SimpleGrid(stickers[category].indices.toList(), columns = 6, spacing = 8.dp) { i ->
            val isSelected = selected == i
            val shape = RoundedCornerShape(14.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(shape)
                    .background(NavyCardHigh.copy(alpha = 0.9f))
                    .then(
                        if (isSelected) {
                            Modifier.border(2.dp, BrandGradient, shape)
                        } else {
                            Modifier.border(1.dp, StrokeSoft, shape)
                        },
                    )
                    .clickable { selected = i },
                contentAlignment = Alignment.Center,
            ) {
                Text(stickers[category][i], fontSize = 26.sp)
            }
        }

        GradientButton(
            text = "Tambah Stiker",
            onClick = { onSoon("Tahap 5") },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
