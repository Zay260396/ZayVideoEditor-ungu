package com.zay.videoeditor.ui.screens.editor

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.Player
import com.zay.videoeditor.data.ImportedClip

/** Pindah ke detik [sec] pada timeline gabungan (semua klip berurutan). */
fun Player.seekToGlobal(clips: List<ImportedClip>, sec: Float) {
    if (clips.isEmpty()) return
    var acc = 0f
    for (i in clips.indices) {
        val end = acc + clips[i].durationSec
        if (sec < end || i == clips.lastIndex) {
            val local = (sec - acc).coerceIn(0f, clips[i].durationSec)
            seekTo(i, (local * 1000f).toLong())
            return
        }
        acc = end
    }
}

/** Posisi pemutar saat ini pada timeline gabungan, dalam detik. */
fun Player.globalPositionSec(clips: List<ImportedClip>): Float {
    var acc = 0f
    val idx = minOf(currentMediaItemIndex, clips.size)
    for (i in 0 until idx) acc += clips[i].durationSec
    return acc + currentPosition / 1000f
}

/** Baca durasi dan nama file video. Mengembalikan null bila video tidak bisa dibaca. */
fun readImportedClip(context: Context, uri: Uri): ImportedClip? {
    val retriever = MediaMetadataRetriever()
    val seconds: Float = try {
        retriever.setDataSource(context, uri)
        val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        ms / 1000f
    } catch (e: Exception) {
        0f
    } finally {
        try {
            retriever.release()
        } catch (e: Exception) {
            // abaikan
        }
    }
    if (seconds <= 0f) return null

    val name: String? = try {
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }
    return ImportedClip(uri, name ?: "Klip", seconds)
}
