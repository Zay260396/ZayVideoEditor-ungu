package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.LabelText
import com.zay.videoeditor.ui.components.NeonChip
import com.zay.videoeditor.ui.components.NeonSlider
import com.zay.videoeditor.ui.components.PanelTabs
import com.zay.videoeditor.ui.theme.NavyCardHigh
import com.zay.videoeditor.ui.theme.NeonBlue
import com.zay.videoeditor.ui.theme.NeonMint
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.NeonPurple
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary

private data class AudioItem(val title: String, val tag: String, val duration: String, val a: Color, val b: Color)

// Daftar contoh. Sumber audio sungguhan (impor dari perangkat) dibangun di TAHAP 5.
private val library = listOf(
    AudioItem("Neon Drive", "Elektronik", "2:14", NeonPurple, NeonBlue),
    AudioItem("Midnight Pulse", "Lo-fi", "3:02", NeonBlue, Color(0xFF2B1B6E)),
    AudioItem("Soft Horizon", "Santai", "1:48", NeonMint, NeonBlue),
    AudioItem("Electric Dawn", "Energik", "2:40", NeonPink, NeonPurple),
    AudioItem("Velvet Sky", "Sinematik", "2:05", Color(0xFFFF7A59), NeonPink),
)

private val effects = listOf(
    AudioItem("Whoosh", "Transisi", "0:02", NeonBlue, NeonPurple),
    AudioItem("Klik", "UI", "0:01", NeonPurple, NeonPink),
    AudioItem("Tepuk Tangan", "Suasana", "0:05", NeonPink, Color(0xFFFF7A59)),
    AudioItem("Ding", "Notifikasi", "0:01", NeonMint, NeonBlue),
)

@Composable
fun MusicPanel(onSoon: (String) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var selected by rememberSaveable { mutableStateOf(-1) }
    var volume by rememberSaveable { mutableStateOf(0.8f) }
    var fadeIn by rememberSaveable { mutableStateOf(true) }
    var fadeOut by rememberSaveable { mutableStateOf(true) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PanelTabs(listOf("Pustaka", "Efek Suara", "Rekam"), tab) {
            tab = it
            selected = -1
        }

        if (tab == 2) {
            Column(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(BrandGradient)
                        .clickable { onSoon("Tahap 5") },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Mic, null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
                Text("Ketuk untuk merekam suara", color = TextSecondary, fontSize = 13.sp)
            }
        } else {
            val items = if (tab == 0) library else effects
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items.forEachIndexed { index, item ->
                    val isSelected = selected == index
                    val shape = RoundedCornerShape(16.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(NavyCardHigh.copy(alpha = 0.9f))
                            .then(
                                if (isSelected) {
                                    Modifier.border(2.dp, BrandGradient, shape)
                                } else {
                                    Modifier.border(1.dp, StrokeSoft, shape)
                                },
                            )
                            .clickable { selected = index }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(item.a, item.b))),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("${item.tag} • ${item.duration}", color = TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                LabelText("Volume", Modifier.width(64.dp))
                NeonSlider(volume, { volume = it }, Modifier.weight(1f))
                Text("${(volume * 100).toInt()}%", color = TextPrimary, fontSize = 13.sp, modifier = Modifier.width(44.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonChip("Fade in", fadeIn, { fadeIn = !fadeIn })
                NeonChip("Fade out", fadeOut, { fadeOut = !fadeOut })
            }

            GradientButton(
                text = "Tambah ke Timeline",
                onClick = { onSoon("Tahap 5") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(4.dp))
    }
}
