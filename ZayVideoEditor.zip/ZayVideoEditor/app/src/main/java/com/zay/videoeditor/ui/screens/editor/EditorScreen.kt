package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.data.DemoTimeline
import com.zay.videoeditor.data.EditorSession
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.IconCircleButton
import com.zay.videoeditor.ui.components.NeonChip
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.components.ToolTile
import com.zay.videoeditor.ui.components.ZayBackground
import com.zay.videoeditor.ui.components.showSoon
import com.zay.videoeditor.ui.theme.Navy
import com.zay.videoeditor.ui.theme.NavyCard
import com.zay.videoeditor.ui.theme.NavyCardHigh
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary
import java.util.Locale

enum class EditorPanel(val label: String, val icon: ImageVector) {
    Trim("Potong", Icons.Rounded.ContentCut),
    Music("Musik", Icons.Rounded.MusicNote),
    Teks("Teks", Icons.Rounded.TextFields),
    Effects("Efek", Icons.Rounded.AutoAwesome),
    Transition("Transisi", Icons.Rounded.SwapHoriz),
    Sticker("Stiker", Icons.Rounded.EmojiEmotions),
}

private fun formatTime(sec: Float): String {
    val m = (sec / 60f).toInt()
    val s = sec - m * 60f
    return String.format(Locale.US, "%02d:%04.1f", m, s)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(onBack: () -> Unit, onExport: () -> Unit) {
    val context = LocalContext.current
    val soon: (String) -> Unit = { stage -> showSoon(context, stage) }

    var panel by rememberSaveable { mutableStateOf<EditorPanel?>(null) }
    var selectedClip by rememberSaveable { mutableStateOf(2) }
    var playhead by rememberSaveable { mutableStateOf(12.5f) }
    var resMenu by remember { mutableStateOf(false) }

    val total = DemoTimeline.TOTAL_SECONDS
    val clips = DemoTimeline.clips
    val videoStarts = clips.filter { it.track == 0 }.map { it.start }.sorted()
    val selected = clips.firstOrNull { it.id == selectedClip }

    ZayBackground {
        Column(Modifier.fillMaxSize()) {
            // Bilah atas
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, onBack)
                Spacer(Modifier.width(12.dp))
                Text(
                    "ZAY EDITOR",
                    modifier = Modifier.weight(1f),
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
                Box {
                    val chipShape = RoundedCornerShape(12.dp)
                    Row(
                        Modifier
                            .clip(chipShape)
                            .background(NavyCardHigh)
                            .border(1.dp, StrokeSoft, chipShape)
                            .clickable { resMenu = true }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            EditorSession.resolutions[EditorSession.resolutionIndex],
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Icon(Icons.Rounded.KeyboardArrowDown, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                    DropdownMenu(expanded = resMenu, onDismissRequest = { resMenu = false }) {
                        EditorSession.resolutions.forEachIndexed { i, r ->
                            DropdownMenuItem(
                                text = { Text(r) },
                                onClick = {
                                    EditorSession.resolutionIndex = i
                                    resMenu = false
                                },
                            )
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                GradientButton(
                    text = "Export",
                    onClick = onExport,
                    height = 38.dp,
                    horizontalPadding = 18.dp,
                )
            }

            // Pratinjau (gradasi pengganti; pemutar video sungguhan di TAHAP 3)
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF2B1B6E), Color(0xFF8A2BE2), Color(0xFFFF7A59)),
                        ),
                    )
                    .border(1.dp, StrokeSoft, RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.4f))
                        .clickable { soon("Tahap 3") },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Icon(
                    Icons.Rounded.Fullscreen,
                    null,
                    tint = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .size(22.dp)
                        .clickable { soon("Tahap 3") },
                )
            }

            // Kontrol transport
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "${formatTime(playhead)} / ${formatTime(total)}",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                )
                IconCircleButton(
                    Icons.Rounded.SkipPrevious,
                    onClick = {
                        playhead = videoStarts.lastOrNull { it < playhead - 0.1f } ?: 0f
                    },
                    size = 38.dp,
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(BrandGradient)
                        .clickable { soon("Tahap 3") },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.width(8.dp))
                IconCircleButton(
                    Icons.Rounded.SkipNext,
                    onClick = {
                        playhead = videoStarts.firstOrNull { it > playhead + 0.1f } ?: total
                    },
                    size = 38.dp,
                )
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                    IconCircleButton(Icons.AutoMirrored.Rounded.Undo, { soon("Tahap 4") }, size = 36.dp)
                    Spacer(Modifier.width(6.dp))
                    IconCircleButton(Icons.AutoMirrored.Rounded.Redo, { soon("Tahap 4") }, size = 36.dp)
                }
            }

            // Info klip terpilih + tombol tambah media
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (selected != null) {
                        "Terpilih: ${selected.label} • ${String.format(Locale.US, "%.1f", selected.length)} dtk"
                    } else {
                        "Ketuk klip untuk memilih"
                    },
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
                GradientButton(
                    text = "Media",
                    icon = Icons.Rounded.Add,
                    onClick = { soon("Tahap 3") },
                    height = 34.dp,
                    horizontalPadding = 14.dp,
                )
            }

            // Timeline multi-layer
            TimelineView(
                clips = clips,
                selectedId = selectedClip,
                onSelect = { selectedClip = it },
                playhead = playhead,
                onSeek = { playhead = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            )

            Spacer(Modifier.weight(1f))

            // Bilah alat
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                EditorPanel.entries.forEach { p ->
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(NavyCard)
                            .border(1.dp, StrokeSoft, RoundedCornerShape(14.dp))
                            .clickable { panel = p }
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(p.icon, p.label, tint = Color.White, modifier = Modifier.size(22.dp))
                        Text(p.label, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        }
    }

    val current = panel
    if (current != null) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { panel = null },
            sheetState = sheetState,
            containerColor = Navy,
            contentColor = TextPrimary,
            scrimColor = Color.Black.copy(alpha = 0.4f),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom))
                    .padding(bottom = 16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(current.icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        current.label,
                        modifier = Modifier.weight(1f),
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    IconCircleButton(Icons.Rounded.Close, { panel = null }, size = 36.dp)
                }
                Spacer(Modifier.height(14.dp))
                Box(
                    Modifier
                        .heightIn(max = 440.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    when (current) {
                        EditorPanel.Trim -> TrimPanel(soon)
                        EditorPanel.Music -> MusicPanel(soon)
                        EditorPanel.Teks -> TextPanel(soon)
                        EditorPanel.Effects -> EffectsPanel(soon)
                        EditorPanel.Transition -> TransitionPanel(soon)
                        EditorPanel.Sticker -> StickerPanel(soon)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrimPanel(onSoon: (String) -> Unit) {
    val tools = listOf(
        "Belah" to Icons.Rounded.ContentCut,
        "Hapus" to Icons.Rounded.Close,
        "Duplikat" to Icons.Rounded.Add,
    )
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            "Pilih klip di timeline, lalu gunakan alat di bawah.",
            color = TextSecondary,
            fontSize = 13.sp,
        )
        SimpleGrid(tools, columns = 3) { (label, icon) ->
            ToolTile(icon, label, selected = false, onClick = { onSoon("Tahap 4") }, modifier = Modifier.fillMaxWidth())
        }
    }
}
