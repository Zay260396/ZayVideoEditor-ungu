package com.zay.videoeditor.ui.theme

import androidx.compose.ui.graphics.Color

// Palet resmi ZAY: neon ungu, biru, pink di atas navy gelap.
val NavyDeep = Color(0xFF070B1F)
val Navy = Color(0xFF0D1330)
val NavyCard = Color(0xFF151B3F)
val NavyCardHigh = Color(0xFF1E2655)

val NeonPurple = Color(0xFF9D4DFF)
val NeonBlue = Color(0xFF3DA5FF)
val NeonPink = Color(0xFFFF4DC4)
val NeonOrange = Color(0xFFFFA24D)
val NeonAmber = Color(0xFFFFD84D)
val NeonMint = Color(0xFF2DE2B5)

val TextPrimary = Color(0xFFF4F1FF)
val TextSecondary = Color(0xFFA9AED6)
val StrokeSoft = Color(0x33FFFFFF)
