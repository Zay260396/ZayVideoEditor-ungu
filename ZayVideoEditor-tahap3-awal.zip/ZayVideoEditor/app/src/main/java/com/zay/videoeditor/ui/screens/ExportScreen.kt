package com.zay.videoeditor.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.data.DemoTimeline
import com.zay.videoeditor.data.EditorSession
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.IconCircleButton
import com.zay.videoeditor.ui.components.LabelText
import com.zay.videoeditor.ui.components.NeonChip
import com.zay.videoeditor.ui.components.ZayBackground
import com.zay.videoeditor.ui.components.showSoon
import com.zay.videoeditor.ui.theme.NavyCardHigh
import com.zay.videoeditor.ui.theme.NeonAmber
import com.zay.videoeditor.ui.theme.NeonPurple
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary
import java.util.Locale

private data class ResOption(val label: String, val size: String, val baseMbps: Float, val badge: String?)

private val resOptions = listOf(
    ResOption("720p", "1280×720", 5f, null),
    ResOption("1080p", "1920×1080", 10f, "Disarankan"),
    ResOption("4K", "3840×2160", 35f, "Ultra"),
)

@Composable
fun ExportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("zay_prefs", Context.MODE_PRIVATE) }
    var saveToGallery by remember { mutableStateOf(prefs.getBoolean("save_to_gallery", true)) }
    var fpsIndex by rememberSaveable { mutableStateOf(1) }
    var qualityIndex by rememberSaveable { mutableStateOf(1) }

    val fpsOptions = listOf(24, 30, 60)
    val qualityLabels = listOf("Hemat", "Seimbang", "Tinggi")
    val qualityFactors = listOf(0.7f, 1f, 1.4f)

    val res = resOptions[EditorSession.resolutionIndex]
    val mbps = res.baseMbps * qualityFactors[qualityIndex] * (fpsOptions[fpsIndex] / 30f)
    val estimatedMb = mbps * DemoTimeline.TOTAL_SECONDS / 8f
    val estimateText = String.format(Locale.forLanguageTag("id-ID"), "%.1f MB", estimatedMb)

    ZayBackground {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconCircleButton(Icons.AutoMirrored.Rounded.ArrowBack, onBack)
                Text(
                    "Ekspor",
                    modifier = Modifier.weight(1f),
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.width(40.dp))
            }

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                // Pratinjau proyek (gradasi pengganti; frame sungguhan di TAHAP 3)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF2B1B6E), Color(0xFF8A2BE2), Color(0xFFFF7A59)),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                }

                Text("Pilih Resolusi", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    resOptions.forEachIndexed { index, option ->
                        val selected = EditorSession.resolutionIndex == index
                        val shape = RoundedCornerShape(18.dp)
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(shape)
                                .background(NavyCardHigh.copy(alpha = 0.9f))
                                .then(
                                    if (selected) {
                                        Modifier.border(2.dp, BrandGradient, shape)
                                    } else {
                                        Modifier.border(1.dp, StrokeSoft, shape)
                                    },
                                )
                                .clickable { EditorSession.resolutionIndex = index }
                                .padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Text(option.label, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                            Text(option.size, color = TextSecondary, fontSize = 11.sp)
                            if (option.badge != null) {
                                Text(
                                    option.badge,
                                    color = if (option.label == "4K") NeonAmber else NeonPurple,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                )
                            } else {
                                Spacer(Modifier.height(12.dp))
                            }
                        }
                    }
                }

                if (res.label == "4K") {
                    Text(
                        "4K hanya tersedia jika HP dan video sumber mendukung. Dicek otomatis saat ekspor (Tahap 6).",
                        color = TextSecondary,
                        fontSize = 12.sp,
                    )
                }

                LabelText("Frame rate")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    fpsOptions.forEachIndexed { i, fps ->
                        NeonChip("$fps fps", fpsIndex == i, { fpsIndex = i })
                    }
                }

                LabelText("Kualitas")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    qualityLabels.forEachIndexed { i, label ->
                        NeonChip(label, qualityIndex == i, { qualityIndex = i })
                    }
                }

                // Simpan ke Galeri
                val rowShape = RoundedCornerShape(18.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(rowShape)
                        .background(NavyCardHigh.copy(alpha = 0.6f))
                        .border(1.dp, StrokeSoft, rowShape)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Simpan ke Galeri", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("Perkiraan ukuran: $estimateText", color = TextSecondary, fontSize = 12.sp)
                    }
                    Switch(
                        checked = saveToGallery,
                        onCheckedChange = {
                            saveToGallery = it
                            prefs.edit().putBoolean("save_to_gallery", it).apply()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NeonPurple,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = NavyCardHigh,
                        ),
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Check, null, tint = NeonPurple, modifier = Modifier.size(16.dp))
                    Text("MP4 • tanpa watermark", color = TextSecondary, fontSize = 12.sp)
                }
            }

            GradientButton(
                text = "Export Video 🚀",
                onClick = { showSoon(context, "Tahap 6") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            )
        }
    }
}
