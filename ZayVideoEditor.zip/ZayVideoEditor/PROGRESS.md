# ZAY VIDEO EDITOR — Catatan Progres

> Baca file ini PERTAMA di setiap percakapan baru, lalu lanjutkan dari tahap terakhir. Jangan mulai ulang.

## Referensi desain resmi
`docs/konsep/zay-konsep-resmi.png` — jangan ubah identitas desain tanpa persetujuan pemilik.
Neon ungu/biru/pink + navy, kartu membulat, gradasi, bottom bar 4 tab (Beranda, Proyek, Template, Profil).

## Teknologi (versi dipilih untuk saling kompatibel)
- AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21 (plugin compose), JDK 17
- Compose BOM 2024.12.01 (Material3 1.3.x), Activity-Compose 1.9.3, Navigation-Compose 2.8.5
- compileSdk/targetSdk 35, minSdk 26
- Media3 1.5.1 (exoplayer + ui) sudah ada untuk pemutar (Tahap 3); Transformer/ekspor masuk Tahap 6

## Status tahap
| Tahap | Isi | Status |
|---|---|---|
| 1 | Struktur proyek + desain semua halaman | SELESAI, build hijau, tampil di HP |
| 2 | Navigasi & interaksi UI | Sebagian sudah ada (lihat bawah) |
| 3 | Impor video, preview, timeline sungguhan | KODE SELESAI (v0.2.0), **BELUM DI-BUILD/DIUJI** |
| 4 | Potong/gabung/atur klip, undo/redo, simpan proyek | Belum |
| 5 | Musik, teks, efek, transisi, stiker sungguhan | Belum |
| 6 | Mesin ekspor MP4 720p/1080p/4K | Belum |
| 7 | Pengujian, perbaikan, APK | Belum |

## Batasan lingkungan
Workspace Claude TIDAK bisa mengunduh Android SDK/Gradle plugin/Maven (diblokir), jadi build
dilakukan lewat GitHub Actions (`.github/workflows/build-apk.yml`) atau Android Studio.
Build hijau untuk Tahap 1. Tahap 3 baru ditulis dan belum dikompilasi; perbaiki error build-nya dulu bila ada.

## Yang sudah benar-benar berfungsi (logika UI nyata, belum diuji di perangkat)
Splash→Onboarding (flag disimpan)→Beranda; tab bawah; filter & pencarian proyek; chip tab panel;
memilih klip & mengetuk timeline untuk memindah playhead; tombol lompat klip sebelum/berikut;
pemilih resolusi (dibagi ke layar Ekspor); estimasi ukuran file; pratinjau teks (font/warna/gaya/ukuran);
saklar pengaturan tersimpan di SharedPreferences ("zay_prefs").

## Tahap 3 (v0.2.0)
Tombol + Media membuka pemilih video galeri (maks 10 sekali pilih, tanpa izin storage). Video masuk ke `EditorSession.clips`,
tampil sebagai klip di lapisan Video (berurutan), diputar ExoPlayer di pratinjau (putar/jeda, lompat klip, ketuk timeline untuk seek).
Sebelum ada video yang diimpor, editor masih menampilkan timeline contoh. Setelah impor, lapisan Teks/Musik/Efek kosong (Tahap 5).
Klip impor belum bisa dihapus (Tahap 4) dan belum tersimpan antar sesi aplikasi.

## Yang MASIH PLACEHOLDER (menampilkan toast "Fitur ini aktif di Tahap X")
Undo/redo, belah/hapus/duplikat, tambah musik/teks/efek/transisi/stiker ke timeline,
rekam suara, tombol Export Video, bahasa/kualitas bawaan/hapus cache di Profil.
Data proyek, klip timeline, daftar musik, dan thumbnail adalah DATA CONTOH (`data/DemoData.kt`).

## Peta kode
- `ZayApp.kt` navigasi (splash, onboarding, main, editor, export)
- `ui/theme/` warna & tema; `ui/components/Neon.kt` komponen bersama (`showSoon()` = penanda fitur belum dibangun)
- `ui/screens/` Splash, Onboarding, Main(+Home, Projects, Template, Profile), Export
- `ui/screens/editor/` Editor, TimelineView, panel Musik/Teks/Efek/Transisi/Stiker
- `data/DemoData.kt` data contoh + `EditorSession` + `ImportedClip` (sementara, diganti ViewModel di Tahap 4)
- `ui/screens/editor/PlayerHelper.kt` seek/posisi gabungan ExoPlayer + pembaca durasi video; `res/layout/zay_player_view.xml` PlayerView

## Deviasi dari konsep (perlu persetujuan jika ingin diubah)
- Foto model di hero Beranda diganti ilustrasi gradasi + headphone (belum ada aset foto).
- Ikon mahkota di header Beranda dan badge mahkota 4K tidak dipakai (belum ada fungsinya; 4K diberi label "Ultra").
- Thumbnail foto proyek diganti gradasi sampai Tahap 3.

## Riwayat build
- Build #2 (GitHub Actions): gagal di compileDebugKotlin, 1 error: TextPanel.kt:138 `padding` belum di-import. SUDAH DIPERBAIKI (import ditambahkan). Menunggu build #3.
- Cara build dari HP: unggah ZayVideoEditor.zip ke repo GitHub, jalankan workflow `build.yml` (mengekstrak zip lalu gradle assembleDebug).
