# ZAY VIDEO EDITOR — Catatan Progres

> Baca file ini PERTAMA di setiap percakapan baru, lalu lanjutkan dari tahap terakhir. Jangan mulai ulang.

## Referensi desain resmi
`docs/konsep/zay-konsep-resmi.png` — jangan ubah identitas desain tanpa persetujuan pemilik.
Neon ungu/biru/pink + navy, kartu membulat, gradasi, bottom bar 4 tab (Beranda, Proyek, Template, Profil).

## Teknologi (versi dipilih untuk saling kompatibel)
- AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21 (plugin compose), JDK 17
- Compose BOM 2024.12.01 (Material3 1.3.x), Activity-Compose 1.9.3, Navigation-Compose 2.8.5
- compileSdk/targetSdk 35, minSdk 26
- Media3 1.5.1: exoplayer + ui (pemutar, Tahap 3), transformer + effect (ekspor MP4, Tahap 6)

## Status tahap
| Tahap | Isi | Status |
|---|---|---|
| 1 | Struktur proyek + desain semua halaman | SELESAI, build hijau, tampil di HP |
| 2 | Navigasi & interaksi UI | Sebagian sudah ada (lihat bawah) |
| 3 | Impor video, preview, timeline sungguhan | SELESAI, diuji di HP (impor, timeline, putar OK) |
| 4a | Belah/hapus/duplikat/geser klip + undo/redo | KODE SELESAI (v0.3.0), **BELUM DI-BUILD/DIUJI** |
| 4b | Simpan proyek (salin video ke penyimpanan app, daftar proyek nyata) | KODE SELESAI (v0.4.0), **BELUM DI-BUILD/DIUJI** (4a juga belum diuji) |
| 4c | Ganti nama proyek, hapus cache di Profil | KODE SELESAI (v0.4.1), **BELUM DI-BUILD/DIUJI**. Kode 4a-4c sudah ditinjau manual (tanpa compiler) dan tidak ditemukan error kompilasi yang jelas |
| 4d | Pilihan rasio sosial media (16:9, 9:16, 1:1, 4:5, 4:3, 21:9) + mode Pas/Isi | KODE SELESAI (v0.4.2), **BELUM DI-BUILD/DIUJI** |
| 5a | Audio: musik dari file, rekam suara, volume, geser, hapus | KODE SELESAI (v0.5.0), **BELUM DI-BUILD/DIUJI** |
| 5b | Teks dan stiker di atas video | Belum |
| 5c | Efek dan transisi | Belum |
| 6 | Mesin ekspor MP4 720p/1080p/4K + mode layar penuh | KODE SELESAI (v0.6.0), **BELUM DI-BUILD/DIUJI** |
| 7 | Pengujian, perbaikan, APK | Belum |

## Batasan lingkungan
Workspace Claude TIDAK bisa mengunduh Android SDK/Gradle plugin/Maven (diblokir), jadi build
dilakukan lewat GitHub Actions (`.github/workflows/build-apk.yml`) atau Android Studio.
Build #9 (GitHub Actions, assembleDebug) sukses sebelum Tahap 6 ditambahkan. Kode Tahap 6 (v0.6.0) ditulis TANPA compiler dan
TANPA akses ke jar Media3, jadi API Media3 diketik dari ingatan: jalankan build dulu dan perbaiki error-nya sebelum lanjut Tahap 5b/5c.

## Yang sudah benar-benar berfungsi (logika UI nyata, belum diuji di perangkat)
Splash→Onboarding (flag disimpan)→Beranda; tab bawah; filter & pencarian proyek; chip tab panel;
memilih klip & mengetuk timeline untuk memindah playhead; tombol lompat klip sebelum/berikut;
pemilih resolusi (dibagi ke layar Ekspor); estimasi ukuran file; pratinjau teks (font/warna/gaya/ukuran);
saklar pengaturan tersimpan di SharedPreferences ("zay_prefs").

## Tahap 3 (v0.2.0)
Tombol + Media membuka pemilih video galeri (maks 10 sekali pilih, tanpa izin storage). Video masuk ke `EditorSession.clips`,
tampil sebagai klip di lapisan Video (berurutan), diputar ExoPlayer di pratinjau (putar/jeda, lompat klip, ketuk timeline untuk seek).
Sebelum ada video yang diimpor, editor masih menampilkan timeline contoh. Setelah impor, lapisan Teks/Musik/Efek kosong (Tahap 5).
Klip impor belum bisa dihapus (Tahap 4) dan belum tersimpan antar sesi aplikasi.

## Tahap 4a (v0.3.0)
Panel Potong: Belah (di posisi playhead pada klip terpilih), Hapus, Duplikat, Geser kiri/kanan. Undo/redo (maks 50 langkah)
menyimpan snapshot daftar klip di `EditorSession`. Klip menyimpan `trimStartSec..trimEndSec` dari file asli; pemutar memakai
`MediaItem.ClippingConfiguration`. Impor juga bisa di-undo.

## Tahap 4b (v0.4.0)
`data/ProjectStore.kt`: proyek disimpan sebagai JSON di `filesDir/projects/<id>.json`, video disalin ke `filesDir/media/` saat impor
(jadi proyek tetap utuh walau file asli dihapus). Simpan otomatis tiap timeline/resolusi berubah, saat keluar editor, dan saat aplikasi ke latar.
Beranda dan halaman Proyek menampilkan proyek nyata (bukan data contoh). Titik tiga di kartu proyek: favorit / hapus.
Proyek baru dibuat dari tombol Proyek Baru; file proyek baru muncul setelah video pertama diimpor. Timeline proyek kosong tidak lagi berisi contoh.
Tahap 4c (v0.4.1): ganti nama proyek (titik tiga di kartu > Ganti nama) dan Hapus cache di Profil sudah berfungsi.
Belum ada: thumbnail asli (masih gradasi). Saklar "Simpan otomatis" di Profil belum dipakai (simpan otomatis selalu aktif).

## Tahap 4d (v0.4.2) - Rasio
`EditorSession.aspects/aspectIndex/fillFrame/outputSize()`. Chip "Rasio" di baris Media membuka panel rasio. Pratinjau mengikuti rasio
(tinggi maks 250dp); mode Pas = resize_mode fit, Isi = zoom. Tersimpan di JSON proyek (`aspect`, `fill`). Layar Ekspor menampilkan rasio dan
ukuran piksel. Mesin ekspor (Tahap 6) WAJIB memakai `EditorSession.outputSize()` dan `fillFrame` (Presentation crop/letterbox).

## Tahap 5a (v0.5.0) - Audio
`data/DemoData.kt`: `AudioClip`, `EditorSession.audioClips` (+ add/delete/setAudioVolume/moveAudio). Disimpan di JSON proyek (`audios`).
`ui/screens/editor/AudioHelper.kt`: salin audio, `VoiceRecorder` (MediaRecorder, m4a, izin RECORD_AUDIO), `AudioMixer` (satu ExoPlayer per klip,
disinkronkan dengan playhead tiap 100 ms). Panel Musik = tambah musik, rekam suara, pilih klip, volume (Bisu/25/50/75/100), pindah ke playhead, hapus.
Audio tampil di lapisan Musik pada timeline. Batasan: audio belum bisa dibelah/dipotong, belum masuk undo/redo, hanya terdengar saat video
diputar (butuh minimal satu video), volume maksimal 100%. Audio ikut hasil ekspor sejak Tahap 6.

## Tahap 6 (v0.6.0) - Ekspor MP4 dan layar penuh
`export/ExportManager.kt` (objek global, status `ExportManager.state` = Idle/Running/Done/Failed). Memakai Media3 Transformer:
- Video: semua klip timeline berurutan (trim dari `ImportedClip.toMediaItem()`), tiap klip diberi `Presentation.createForWidthAndHeight(w, h, layout)`
  dengan w,h dari `EditorSession.outputSize()`; layout `SCALE_TO_FIT` (mode Pas) atau `SCALE_TO_FIT_WITH_CROP` (mode Isi). H.264 + AAC.
- Audio: suara asli klip ikut bila SEMUA klip punya trek suara (jika ada klip bisu, suara asli dibuang semua). Tiap `AudioClip` (musik/suara)
  = satu sequence sendiri; Transformer mencampur semua sequence. Posisi mulai dibuat dengan file WAV hening di depan audio
  (cache, dihapus setelah ekspor). Volume lewat `GainAudioProcessor`. Audio dipotong bila melewati akhir video; audio yang mulai
  setelah video selesai dilewati.
- Bitrate = dasar resolusi x faktor kualitas x faktor jumlah piksel rasio (dihitung di ExportScreen). Encoder fallback aktif (4K diturunkan otomatis bila HP tidak mampu).
- Hasil: ditulis ke `filesDir/exports/ZAY_<waktu>.mp4`; bila saklar "Simpan ke Galeri" aktif dan Android 10+, disalin ke Movies/ZAY Video Editor
  (MediaStore) lalu file internal dihapus. Android 9 ke bawah atau gagal: tetap di penyimpanan aplikasi (dibuka lewat FileProvider).
- ExportScreen: tombol Export Video memulai ekspor; kartu progres (Batal), kartu selesai (Putar, Bagikan, Selesai), kartu gagal (pesan error + kode).
  Layar tetap menyala selama ekspor; tombol kembali dikunci saat ekspor berjalan.
Layar penuh: `ui/screens/editor/FullscreenPlayer.kt`, dibuka dari ikon Fullscreen di pratinjau editor. Menyembunyikan bilah sistem, memutar ke
lanskap untuk rasio >= 1, memakai ExoPlayer yang sama, ketuk layar = tampil/sembunyi kontrol (putar/jeda, slider, waktu), tombol kembali menutup.
Manifest: `configChanges` pada MainActivity (rotasi tidak membuat ulang activity), FileProvider + `res/xml/file_paths.xml`.
Batasan Tahap 6: frame rate hasil mengikuti video sumber (chip fps belum berefek); teks/stiker/efek/transisi belum ada jadi belum ikut;
ekspor berjalan di dalam aplikasi (jika aplikasi dimatikan sistem saat di latar, ekspor berhenti; belum ada foreground service);
tidak ada pemeriksaan ruang penyimpanan sebelum ekspor.
Jika build gagal, tersangka pertama: nama API di `ExportManager.kt` (konstruktor `EditedMediaItemSequence`, `Composition.Builder`, `ExportException.errorCode`,
`BaseAudioProcessor`) karena belum pernah dikompilasi.

## Yang MASIH PLACEHOLDER (menampilkan toast "Fitur ini aktif di Tahap X")
Tambah teks/efek/transisi/stiker ke timeline, bahasa/kualitas bawaan di Profil.
Data proyek, klip timeline, daftar musik, dan thumbnail adalah DATA CONTOH (`data/DemoData.kt`).

## Peta kode
- `ZayApp.kt` navigasi (splash, onboarding, main, editor, export)
- `ui/theme/` warna & tema; `ui/components/Neon.kt` komponen bersama (`showSoon()` = penanda fitur belum dibangun)
- `ui/screens/` Splash, Onboarding, Main(+Home, Projects, Template, Profile), Export
- `ui/screens/editor/` Editor, TimelineView, panel Musik/Teks/Efek/Transisi/Stiker
- `data/DemoData.kt` data contoh + `EditorSession` + `ImportedClip` (sementara, diganti ViewModel di Tahap 4)
- `export/ExportManager.kt` mesin ekspor MP4 (Media3 Transformer) + `GainAudioProcessor`
- `ui/screens/editor/FullscreenPlayer.kt` pemutar layar penuh
- `ui/screens/editor/PlayerHelper.kt` seek/posisi gabungan ExoPlayer + pembaca durasi video; `res/layout/zay_player_view.xml` PlayerView

## Deviasi dari konsep (perlu persetujuan jika ingin diubah)
- Foto model di hero Beranda diganti ilustrasi gradasi + headphone (belum ada aset foto).
- Ikon mahkota di header Beranda dan badge mahkota 4K tidak dipakai (belum ada fungsinya; 4K diberi label "Ultra").
- Thumbnail foto proyek diganti gradasi sampai Tahap 3.

## Riwayat build
- Build #2 (GitHub Actions): gagal di compileDebugKotlin, 1 error: TextPanel.kt:138 `padding` belum di-import. SUDAH DIPERBAIKI (import ditambahkan). Menunggu build #3.
- Build #9: sukses (assembleDebug, 1m 51s) sebelum Tahap 6. Peringatan saja: Node.js 20 deprecated, setup-java v4 deprecated, ubuntu-latest pindah ke Ubuntu 26 (bisa di-pin ke `ubuntu-24.04`).
- Menunggu build #10 untuk Tahap 6 (v0.6.0).
- Cara build dari HP: unggah ZayVideoEditor.zip ke repo GitHub, jalankan workflow `Build APK` (`.github/workflows/build-apk.yml`) (mengekstrak zip lalu gradle assembleDebug).
