package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.data.DemoTimeline
import com.zay.videoeditor.data.TimelineClip
import com.zay.videoeditor.ui.theme.NavyCard
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextSecondary
import kotlin.math.abs
import kotlin.math.sin

/**
 * Timeline multi-layer: penggaris waktu, 4 lapisan (Video, Teks, Musik, Efek),
 * klip yang bisa dipilih, dan playhead yang bisa digeser dengan mengetuk.
 * Data klip masih contoh; dihubungkan ke video sungguhan pada TAHAP 3-4.
 */
@Composable
fun TimelineView(
    clips: List<TimelineClip>,
    selectedId: Int,
    onSelect: (Int) -> Unit,
    playhead: Float,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    dpPerSec: Float = 34f,
    totalSec: Float = DemoTimeline.TOTAL_SECONDS,
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val tracks = DemoTimeline.tracks
    val rulerH = 26.dp
    val trackH = 42.dp
    val shape = RoundedCornerShape(20.dp)

    Row(
        modifier
            .clip(shape)
            .background(NavyCard.copy(alpha = 0.7f))
            .border(1.dp, StrokeSoft, shape),
    ) {
        // Kolom ikon lapisan
        Column(Modifier.width(44.dp)) {
            Spacer(Modifier.height(rulerH))
            tracks.forEach { t ->
                Box(Modifier.height(trackH).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Icon(t.icon, t.name, tint = t.colors.first(), modifier = Modifier.size(20.dp))
                }
            }
        }

        Box(Modifier.weight(1f).horizontalScroll(scroll)) {
            Box(
                Modifier
                    .width((totalSec * dpPerSec).dp + 24.dp)
                    .height(rulerH + trackH * tracks.size)
                    .pointerInput(dpPerSec, totalSec) {
                        detectTapGestures { offset ->
                            val pxPerSec = with(density) { dpPerSec.dp.toPx() }
                            onSeek((offset.x / pxPerSec).coerceIn(0f, totalSec))
                        }
                    },
            ) {
                // Penggaris waktu
                (0..totalSec.toInt() step 5).forEach { s ->
                    Text(
                        "${s}s",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        modifier = Modifier
                            .offset(x = (s * dpPerSec).dp + 3.dp, y = 6.dp),
                    )
                }

                // Klip
                clips.forEach { item ->
                    val track = tracks[item.track]
                    val selected = item.id == selectedId
                    val clipShape = RoundedCornerShape(10.dp)
                    Box(
                        Modifier
                            .offset(x = (item.start * dpPerSec).dp, y = rulerH + trackH * item.track + 3.dp)
                            .width((item.length * dpPerSec).dp)
                            .height(trackH - 6.dp)
                            .clip(clipShape)
                            .background(Brush.horizontalGradient(track.colors))
                            .then(
                                if (selected) Modifier.border(2.dp, Color.White, clipShape) else Modifier,
                            )
                            .clickable { onSelect(item.id) }
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        if (track.isAudio) {
                            Canvas(Modifier.matchParentSize()) {
                                val barW = 3.dp.toPx()
                                val gap = 3.dp.toPx()
                                var x = 0f
                                var i = 0
                                while (x < size.width) {
                                    val h = (0.25f + 0.6f * abs(sin(i * 0.7f))) * size.height
                                    drawRoundRect(
                                        color = Color.White.copy(alpha = 0.35f),
                                        topLeft = Offset(x, (size.height - h) / 2f),
                                        size = Size(barW, h),
                                        cornerRadius = CornerRadius(barW / 2f),
                                    )
                                    x += barW + gap
                                    i++
                                }
                            }
                        }
                        Text(
                            item.label,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                // Playhead
                Box(
                    Modifier
                        .offset(x = (playhead * dpPerSec).dp - 1.dp)
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(Color.White),
                )
                Box(
                    Modifier
                        .offset(x = (playhead * dpPerSec).dp - 6.dp, y = 2.dp)
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(NeonPink),
                )
            }
        }
    }
}
