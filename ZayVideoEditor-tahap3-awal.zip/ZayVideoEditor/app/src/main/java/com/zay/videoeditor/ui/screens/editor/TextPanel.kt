package com.zay.videoeditor.ui.screens.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FormatBold
import androidx.compose.material.icons.rounded.FormatItalic
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zay.videoeditor.ui.components.BrandGradient
import com.zay.videoeditor.ui.components.GradientButton
import com.zay.videoeditor.ui.components.NeonChip
import com.zay.videoeditor.ui.components.NeonSlider
import com.zay.videoeditor.ui.components.PanelTabs
import com.zay.videoeditor.ui.components.SimpleGrid
import com.zay.videoeditor.ui.theme.NavyCard
import com.zay.videoeditor.ui.theme.NavyCardHigh
import com.zay.videoeditor.ui.theme.NeonAmber
import com.zay.videoeditor.ui.theme.NeonBlue
import com.zay.videoeditor.ui.theme.NeonMint
import com.zay.videoeditor.ui.theme.NeonPink
import com.zay.videoeditor.ui.theme.NeonPurple
import com.zay.videoeditor.ui.theme.StrokeSoft
import com.zay.videoeditor.ui.theme.TextPrimary
import com.zay.videoeditor.ui.theme.TextSecondary
import com.zay.videoeditor.ui.components.zayFieldColors

private val fontChoices = listOf(
    "Classic" to FontFamily.Serif,
    "Modern" to FontFamily.SansSerif,
    "Kode" to FontFamily.Monospace,
    "Cute" to FontFamily.Cursive,
)

private val colorChoices = listOf(
    Color.White,
    Color.Black,
    NeonPurple,
    NeonPink,
    NeonBlue,
    NeonMint,
    NeonAmber,
)

private val animChoices = listOf("Tanpa", "Fade", "Naik", "Zoom", "Ketik", "Pantul")

@Composable
fun TextPanel(onSoon: (String) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var text by rememberSaveable { mutableStateOf("ZAY VIDEO EDITOR") }
    var fontIndex by rememberSaveable { mutableStateOf(1) }
    var colorIndex by rememberSaveable { mutableStateOf(0) }
    var animIndex by rememberSaveable { mutableStateOf(0) }
    var bold by rememberSaveable { mutableStateOf(true) }
    var italic by rememberSaveable { mutableStateOf(false) }
    var textSize by rememberSaveable { mutableStateOf(48f) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Pratinjau teks (menggunakan pilihan font, warna, gaya, dan ukuran)
        Box(
            Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(NavyCardHigh),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text.ifBlank { "Teks" },
                color = colorChoices[colorIndex],
                fontFamily = fontChoices[fontIndex].second,
                fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.Normal,
                fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
                fontSize = (textSize * 0.6f).sp,
                lineHeight = (textSize * 0.72f).sp,
                maxLines = 2,
                textAlign = TextAlign.Center,
            )
        }

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Teks") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = zayFieldColors(),
        )

        PanelTabs(listOf("Font", "Warna", "Animasi", "Gaya"), tab) { tab = it }

        when (tab) {
            0 -> SimpleGrid(fontChoices.indices.toList(), columns = 4, spacing = 8.dp) { i ->
                val selected = fontIndex == i
                val shape = RoundedCornerShape(16.dp)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(NavyCardHigh.copy(alpha = 0.9f))
                        .then(
                            if (selected) {
                                Modifier.border(2.dp, BrandGradient, shape)
                            } else {
                                Modifier.border(1.dp, StrokeSoft, shape)
                            },
                        )
                        .clickable { fontIndex = i }
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Aa", color = TextPrimary, fontSize = 22.sp, fontFamily = fontChoices[i].second, fontWeight = FontWeight.Bold)
                    Text(fontChoices[i].first, color = TextSecondary, fontSize = 11.sp)
                }
            }

            1 -> Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                colorChoices.forEachIndexed { i, c ->
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(c)
                            .then(
                                if (colorIndex == i) {
                                    Modifier.border(3.dp, BrandGradient, CircleShape)
                                } else {
                                    Modifier.border(1.dp, StrokeSoft, CircleShape)
                                },
                            )
                            .clickable { colorIndex = i },
                    )
                }
            }

            2 -> Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        animChoices.take(3).forEachIndexed { i, a -> NeonChip(a, animIndex == i, { animIndex = i }) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        animChoices.drop(3).forEachIndexed { i, a -> NeonChip(a, animIndex == i + 3, { animIndex = i + 3 }) }
                    }
                }
            }

            else -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StyleToggle(Icons.Rounded.FormatBold, bold) { bold = !bold }
                StyleToggle(Icons.Rounded.FormatItalic, italic) { italic = !italic }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ukuran Teks", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(88.dp))
            NeonSlider(textSize, { textSize = it }, Modifier.weight(1f), valueRange = 16f..96f)
            Text("${textSize.toInt()}", color = TextPrimary, fontSize = 13.sp, modifier = Modifier.width(32.dp), textAlign = TextAlign.End)
        }

        GradientButton(
            text = "Tambahkan ke Video",
            onClick = { onSoon("Tahap 5") },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun StyleToggle(icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .size(48.dp)
            .clip(shape)
            .then(
                if (selected) {
                    Modifier.background(BrandGradient)
                } else {
                    Modifier.background(NavyCard).border(1.dp, StrokeSoft, shape)
                },
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
    }
}
